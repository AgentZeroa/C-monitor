# -*- coding: utf-8 -*-

import common

def getCommodityListBySerach(control_name, keyword = 'SSS'):
    errNum = '9'
    url = ''
    logName = control_name + '_getCommodityListBySerach_log.txt'
    apiCode = '[112]'
    logMsg = ''

    # 判断参数是否正确,如果在列表里，则可以开始拼装参数，发送url请求
    parms = common.getConfig(apiCode, logName, control_name)

    if not parms == '-1':
        errNum = '9'
        # 拼装url
        url = 'http://%s/vod_api/commodityList!getCommodityListBySerach?serviceGroupCode=%s&userCode=%s&keyword=%s' % (parms['VOD'], parms['ServiceGroupCode'], parms['UserCode'], keyword)
        url += common.getRandom()  # 获取随机参数
        # 请求接口
        urlRet = common.getUrlRet(url,parms['LOGPath'] + logName)

        # 判断返回值code为200，则检查返回值内容是否正确
        if urlRet['code'] == 200 and 'retMsg' in urlRet['read'] and type(urlRet['read']['retMsg']) == dict and 'listInfo' in urlRet['read']['retMsg']:
            data = urlRet['read']['retMsg']['listInfo']
            # 判断返回值是否正确
            n_list = {'productCode', 'productName', 'action', 'pictureUrl'}
            logMsg += '搜索关键词: ' + keyword + '； '
            if type(data) == list and len(data) > 0 and common.check_list(data[0], n_list, 3) and data[0]['action'] == 'OPEN_DETAIL':
                errNum = '0'
                logMsg += '搜索结果第一条productName：' + data[0]['productName'] + '；\n'
            elif len(data) > 0 and data[0]['action'] == 'OPEN_DETAIL':
                errNum = '770'
                logMsg += '搜索结果第一条:' + str(data[0])
            elif len(data) > 0:
                errNum = '771'
                logMsg += '搜索结果第一条productName：' + data[0]['productName'] + '；action值为' + data[0]['action']
            else:
                errNum = '772'
        else:
            # 连接出现问题，获取错误码信息
            errNum = urlRet['code']

            if 'read' in urlRet:
                logMsg += str(urlRet['read'])

        # 写日志和发邮件的内容在这里组合
        ret = common.log_mail(parms['NAME'], apiCode, errNum, logMsg, url, parms['LOGPath'], logName)
        if ret != 1:
            errNum = '7'

    return errNum

# if config_api.GLOBAL_debugType == 1:
#     getNavigationInfo('SCYD')
