#!/usr/bin/env python
# -*- coding: utf-8 -*-

import time
import config_api
import common
from getSeriesInfoByCode import getSeriesInfoByCode
from getProductList import getProductList
from getCategoryList import getCategoryList

def getRecommendInfo(control_name, recommendCode = ''):
    errNum = '9'
    n = 0
    url = ''
    logName = control_name + '_getRecommendInfo_log.txt'
    apiCode = '[108]'    # 获取推荐位(getRecommendInfo)
    logMsg = ''

    # 判断参数是否正确,如果在列表里，则可以开始拼装参数，发送url请求
    parms = common.getConfig(apiCode, logName, control_name)
    if parms == '-1':
        errNum = '-1'
    elif recommendCode == '' and (parms['RecommendCode'] is False or parms['RecommendName'] is False):
        errNum = '-1'
        common.log_mail(parms['NAME'], apiCode, errNum, logMsg, url, parms['LOGPath'], logName)
    elif recommendCode == '' and parms['RecommendCode'] and parms['RecommendName']:
        for code in parms['RecommendCode']:
            errNum = check_code(control_name, apiCode, code, parms, logName, n)
            n += 1
            if not errNum == '0':
                break
    else:
        errNum = check_code(control_name, apiCode, recommendCode, parms, logName)
    return errNum

def check_code(control_name, apiCode, code, parms, logName, n=99):
    logMsg = ''
    errNum = '9'

    # 拼装url
    url = 'http://%s/oms_api/recommend!getRecommendInfo?recommendCode=%s&comboCode=%s' % (parms['OMS'], code, parms['ServiceComboCode'])
    url += common.getRandom()  # 获取随机参数

    # 请求接口
    urlRet = common.getUrlRet(url, parms['LOGPath'] + logName)

    # 判断返回值code为200，则检查返回值内容是否正确
    if urlRet['code'] == 200 and 'retMsg' in urlRet['read'] and type(urlRet['read']['retMsg']) == dict:
        data = urlRet['read']['retMsg']
        # 判断返回值是否正确
        if 'code' in data and data['code'] == code and 'name' in data and (n == 99 or data['name'] in parms['RecommendName']):
            logMsg += '获取推荐位——' + data['name'] + '数据为：\n'
            ret_msg = check_info(data, parms, n, control_name, url)
            errNum = ret_msg[0]
            logMsg += ret_msg[1]
        else:
            errNum = '702'
    else:
        # 连接出现问题，获取错误码信息
        errNum = urlRet['code']
        if len(str(urlRet['read'])) < 500:
            logMsg += str(urlRet['read']) + '\n'

    # 写日志和发邮件的内容在这里组合
    ret = common.log_mail(parms['NAME'], apiCode, errNum, logMsg, url, parms['LOGPath'], logName, parms['dingding_token'])
    if ret != 1:
        errNum = '7'

    return errNum


def check_info(urlRet, parms, n, control_name, url):
    logMsg = ''
    errNum = '9'
    ret_msg = []
    posterUrl = 'posterUrl'
    un_check_image = {'SZTW'}
    imageLogName = control_name + '_image_log.txt'
    # 判断推荐位的数量是否返回正确，将数量存在content_num中，与接下来实际获取的数量进行比较
    if 'recommendTemplate' in urlRet and type(urlRet['recommendTemplate']) == dict and 'recommendPosition' in urlRet['recommendTemplate'] \
            and type(urlRet['recommendTemplate']['recommendPosition']) == list and len(urlRet['recommendTemplate']['recommendPosition']) > 0:
        content_num = 0
        for i in urlRet['recommendTemplate']['recommendPosition']:
            if 'parttern' in i and i['parttern'] > 1:
                content_num += i['parttern'] // 10
                errNum = '0'
            else:
                errNum = '705'
                break
    else:
        errNum = '708'

    # 判断各个推荐位是否正确，判断推荐位的总数、action、code，对纳入监控范围的name也进行验证
    if 'recommendContent' in urlRet and type(urlRet['recommendContent']) == list and errNum == '0':
        logMsg += 'recommendPosition的个数为：' + str(content_num) + '\n'
        length = 0
        for content in urlRet['recommendContent']:
            content_name = 'Recommend_' + str(n)
            if not 'action' in content or (not content['action'] in config_api.GLOBAL_action):
                errNum = '703'
                if 'action' in content:
                    logMsg += 'name: %s，action: %s。\n' % (content['name'], content['action'])
                break
            if not 'code' in content or (not 'name' in content) or (len(content['code']) < 5):
                errNum = '704'
                break

            # 判断推荐位海报是否能正常展示
            if not posterUrl in content or len(content[posterUrl]) < 5:
                errNum = '787'
                logMsg += content['name'] + '\n'
                break
            elif not control_name in un_check_image:
                check_image = common.getUrlRet(content[posterUrl], parms['LOGPath'] + imageLogName, type=4)
                if check_image['code'] == 200:
                    errNum = '0'
                else:
                    errNum = '787'
                    logMsg += 'code：%s, name：%s，海报图片：%s \n' % (check_image['code'], content['name'], content[posterUrl])
                    break
            logMsg += '获取的推荐位名称为：' + content['name'] + '；code为：' + content['code'] + '\n'
            errNum = '0'
            # 调用获取节目集详情，判断推荐位的节目是否正常
            if content['action'] == 'OPEN_DETAIL' and 'assetCode' in content:
                getSeriesInfoByCode(control_name, content['assetCode'], False, content['name'], url)
                time.sleep(parms['SleepTime'])
            # 增加推荐位上产品包或专题包的判断
            elif content['action'] == 'OPEN_SPECIAL_TEMPLATE_1' and 'assetCode' in content:
                is_zt = 'Y'
                getProductList(control_name, content['assetCode'], content['name'], 1, url, is_zt)
                time.sleep(parms['SleepTime'])
            # 判断推荐位上挂的栏目/全部专题是否在一级栏目列表中
            elif content['action'] in {'OPEN_PROGRAM_LIST', 'OPEN_SPECIAL_INDEX'} and 'assetCode' in content:
                category_code = getCategoryList(control_name, content['assetCode'])
                if type(category_code) == bool and category_code is True:
                    errNum = '0'
                else:
                    errNum = '7061'
                    logMsg += 'categoryCode: ' + content['assetCode']
                    break
                time.sleep(parms['SleepTime'])
            # 节目集、产品包、专题包的code不能为空
            elif content['action'] in ['OPEN_DETAIL', 'OPEN_SPECIAL_TEMPLATE_1']:
                errNum = '7061'
                break
            if content_name in parms:
                length += 1
                if content['name'] in parms[content_name] or length > len(parms[content_name]):
                    errNum = '0'
                else:
                    errNum = '706'
                    break
        if errNum == '0' and not len(urlRet['recommendContent']) == content_num:
            errNum = '701'
            logMsg += '实际获取的推荐位个数为：' + str(len(urlRet['recommendContent'])) + '\n'
    elif errNum == '0':
        errNum = '707'


    ret_msg = [errNum, logMsg]
    return ret_msg

# 检查EPG5.0推荐位的行尺寸是否符合规定
def check_width(data, width = config_api.GLOBAL_width_2, height = config_api.GLOBAL_height_2):
    check_key = {'width', 'height', 'row'}
    for r_list in data:
        if common.check_list(r_list, check_key, 3):
            if r_list['row'] == 2 and r_list['width'] == width and r_list['height'] == height:
                return True
    return False

# 获取5.0推荐位
def getRecommendInfo5(control_name):
    errNum = '9'
    width = 0
    height = 0
    con_count = 0
    row_count = 0
    url = ''
    logName = control_name + '_getRecommendInfo_log.txt'
    apiCode = '[113]'  # 获取EPG5.0推荐位(getRecommendInfo5)
    logMsg = ''
    posterUrl = 'posterUrl'
    c_list = {'remdList', 'totalRows', 'totalContents'}
    r_list = {'navigationItemCode', 'navigationItemName', 'rowCount', 'remmendList'}
    r_check = {'width', 'height', 'row', 'name', 'contentList'}
    con_list = {'idx',  'serviceType', 'assetCode', 'action'}
    un_empty = {'code', posterUrl}
    vod_un_empty = {'name'}
    h5_un_empty = {'openUrl'}
    live_un_empty = {'liveUrl'}
    app_un_empty = {'apkName', 'apkUrl'}
    show_name = {'showName'}
    un_check_image = {'SZTW5'}

    # 判断参数是否正确,如果在列表里，则可以开始拼装参数，发送url请求
    parms = common.getConfig(apiCode, logName, control_name)

    if not parms == '-1' and parms['NavigationItemCode'] and parms['NavigationName']:
        # 拼装url
        url = 'http://%s/oms_api/recommend5/info?comboCode=%s' % (parms['OMS'], parms['ServiceComboCode'])
        url += common.getRandom()  # 获取随机参数
        # 请求接口
        urlRet = common.getUrlRet(url, parms['LOGPath'] + logName)

        # 判断返回值code为200，则检查返回值内容是否正确
        if urlRet['code'] == 200 and 'retMsg' in urlRet['read'] and type(urlRet['read']['retMsg']) == dict:
            data = urlRet['read']['retMsg']
            # 判断返回值是否正确
            if common.check_list(data, c_list, 3) and type(data['remdList']) == list:
                totalRows = data['totalRows']
                totalContents = data['totalContents']
                data = data['remdList']
                for remend_list in data:
                    # 判断navigationItemCode和name是否在列表中
                    if common.check_list(remend_list, r_list, 3) and type(remend_list['remmendList']) == list and \
                                    remend_list['navigationItemCode'] in parms['NavigationItemCode'] and remend_list['navigationItemName'] in parms['NavigationName']:
                        logMsg += 'navigationItemCode：' + remend_list['navigationItemCode']
                        logMsg += '； NavigationName：' + remend_list['navigationItemName']
                        logMsg += '； rowCount：' + str(remend_list['rowCount']) + '\n'
                        # 判断第一个推荐位的第二行行尺寸是否符合要求
                        if row_count == 0:
                            if config_api.GLOBAL_width_2 and config_api.GLOBAL_height_2:
                                width = config_api.GLOBAL_width_2
                                height = config_api.GLOBAL_height_2
                            if not check_width(remend_list['remmendList']):
                                errNum = '785'
                                logMsg += '第二行宽度应为：%s，高度应为：%s。\n' % (width, height)
                                break
                        row_count += remend_list['rowCount']
                        for rlist in remend_list['remmendList']:
                            # 判断推荐位上的关键节点是否存在
                            if common.check_list(rlist, r_check, 3) and type(rlist['contentList']) == list and len(rlist['contentList']) > 0:
                                con_count += len(rlist['contentList'])
                                show_errNum = 0
                                show_errMsg = ''
                                for content in rlist['contentList']:
                                    if common.check_list(content, con_list, 2) and common.check_list(content, un_empty, 3)\
                                            and content['action'] in config_api.GLOBAL_action :
                                        # 判断推荐位海报是否能正常展示
                                        if not control_name in un_check_image:
                                            check_image = common.getUrlRet(content[posterUrl], parms['LOGPath'] + logName, type=4)
                                            if check_image['code'] == 200:
                                                errNum = '0'
                                            else:
                                                errNum = '787'
                                                logMsg += 'code：%s, name：%s，海报图片：%s \n' % (check_image['code'], content['name'], content[posterUrl])
                                                break

                                        if content['serviceType'] == 'VOD' and common.check_list(content, vod_un_empty, 3):
                                            if not common.check_list(content, show_name, 3):
                                                show_errNum += 1
                                                show_errMsg += content['name'] + '； '
                                            errNum = '0'
                                        elif content['serviceType'] == 'H5' and common.check_list(content, h5_un_empty, 3):
                                            errNum = '0'
                                        elif content['serviceType'] == 'LIVE' and common.check_list(content, live_un_empty, 3):
                                            errNum = '0'
                                        elif content['serviceType'] == 'APP' and common.check_list(content, app_un_empty, 3):
                                            errNum = '0'
                                        else:
                                            errNum = '786'
                                            logMsg += content['serviceType'] + '\n'
                                        # 调用获取节目集详情页
                                        if content['action'] == 'OPEN_DETAIL':
                                            getSeriesInfoByCode(control_name, content['assetCode'], False, content['name'], url)
                                            time.sleep(parms['SleepTime'])
                                        # 增加推荐位上产品包或专题包的判断
                                        elif content['action'] == 'OPEN_SPECIAL_TEMPLATE_1' and 'assetCode' in content:
                                            is_zt = 'Y'
                                            getProductList(control_name, content['assetCode'], content['name'], 1, url, is_zt, procuct_count=config_api.GLOBAL_ZTNum)
                                            time.sleep(parms['SleepTime'])
                                        # 判断推荐位上挂的栏目/全部专题是否在一级栏目列表中
                                        elif content['action'] in {'OPEN_PROGRAM_LIST', 'OPEN_SPECIAL_INDEX'}:
                                            if 'assetCode' in content and getCategoryList(control_name, content['assetCode']):
                                                errNum = '0'
                                            else:
                                                errNum = '7061'
                                                logMsg += 'categoryCode: ' + content['assetCode']

                                            time.sleep(parms['SleepTime'])
                                        # 节目集、专题包的code不能为空
                                        elif content['action'] in ['OPEN_DETAIL', 'OPEN_SPECIAL_TEMPLATE_1']:
                                            errNum = '7061'
                                            break
                                    elif 'action' in content and content['action'] in config_api.GLOBAL_action:
                                        errNum = '784'
                                        logMsg += str(content) + '\n'
                                        break
                                    else:
                                        errNum = '703'
                                        logMsg += 'name：%s，返回action: %s。\n' % (content['name'], content['action'])
                                        break
                                if show_errNum > 0:
                                    logMsg += '%s共有%s个节目集缺少showName：%s \n' % (rlist['name'], show_errNum, show_errMsg)
                            else:
                                errNum = '783'
                                break
                            # 如果出错则跳出循环
                            if not errNum == '0':
                                break
                        if not errNum == '0':
                            break
                    else:
                        errNum = '781'
                        break
                if row_count == totalRows and con_count == totalContents and errNum == '9':
                    errNum = '0'
                elif (not (row_count == totalRows and con_count == totalContents)) and len(errNum) < 3:
                    errNum = '782'
                    logMsg += 'totalRows：' + str(totalRows) + '； 计算值为：' + str(row_count) + '\n'
                    logMsg += 'totalContents：' + str(totalContents) + '； 计算值为：' + str(con_count) + '\n'
            else:
                errNum = '780'
        else:
            # 连接出现问题，获取错误码信息
            errNum = urlRet['code']

        # 写日志和发邮件的内容在这里组合
        ret = common.log_mail(parms['NAME'], apiCode, errNum, logMsg, url, parms['LOGPath'], logName, parms['dingding_token'])
        if ret != 1:
            errNum = '7'

    return errNum

# if config_api.GLOBAL_debugType == 1:
#    getRecommendInfo('SDZX')
