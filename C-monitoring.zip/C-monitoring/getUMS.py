# -*- coding: utf-8 -*-

import common
import urllib.parse
import time

def Favourite(control_name, productCode = '', epg = ''):
    errNum = '9'
    logMsg = ''
    apiCode = '[120]'
    logName = control_name + '_Favourite_log.txt'

    # 判断参数是否正确,如果在列表里，则发送url请求
    parms = common.getConfig(apiCode, logName, control_name)
    list = {'UMS', 'UserCode', 'ServiceComboCode', 'ServiceGroupCode'}
    if not parms == '-1' and common.check_list(parms, list, 3):
        if productCode == '':
            productCode = parms['ProductCode']
        # 收藏相关
        setDelFavouriteInfoByUser(logName, parms, epg)       # 删除所有收藏
        time.sleep(parms['SleepTime'])
        getFavouriteInfoByUser(logName, parms, '', 'A0000000', epg)  # 查询是否已删除
        time.sleep(parms['SleepTime'])
        setFavouriteInfoByUser(logName, parms, productCode, 1, epg)     # 添加收藏
        time.sleep(parms['SleepTime'])
        getProductIsFavourite(logName, parms, productCode, '1', epg)  # 查询收藏是否已经被清空
        time.sleep(parms['SleepTime'])
        getFavouriteInfoByUser(logName, parms, productCode, '', epg)     # 查询收藏
        time.sleep(parms['SleepTime'])
        setFavouriteInfoByUser(logName, parms, productCode, 0, epg)  # 删除收藏
        time.sleep(parms['SleepTime'])
        setFavouriteInfoByUser(logName, parms, productCode, 1, epg)     # 添加收藏
        time.sleep(parms['SleepTime'])
        if control_name == 'JSYD':
            getProductIsFavourite(logName, parms, productCode, '1', epg) # 查询是否收藏指定节目集
            time.sleep(parms['SleepTime'])
    return errNum

def PlayHistory(control_name, productCode, seriesName, pictureUrl, playUrl):
    errNum = '9'
    logMsg = ''
    # 播放记录相关
    apiCode = '[124]'
    logName = control_name + '_PlayHistory_log.txt'
    # 判断参数是否正确,如果在列表里，则发送url请求
    parms = common.getConfig(apiCode, logName, control_name)

    list = {'UMS', 'UserCode'}
    if not parms == '-1' and common.check_list(parms, list, 2):
        setPlayHistoryInfoByUser(logName, parms, productCode, seriesName, pictureUrl, playUrl)  # 添加播放记录
        time.sleep(parms['SleepTime'])
        getPlayHistoryInfoByUser(logName, parms, productCode)       # 查看播放记录
        time.sleep(parms['SleepTime'])
        deletePlayHistoryInfo(logName, parms, productCode)          # 删除播放记录
        time.sleep(parms['SleepTime'])
        ret = getPlayHistoryInfoByUser(logName, parms, productCode, 3, 'A0000000')    # 查看播放记录是否已删除
        time.sleep(parms['SleepTime'])
        # 如果删除播放记录失败，必须重试一次删除，以免影响接口的
        if not ret == '0':
            deletePlayHistoryInfo(logName, parms)  # 删除播放记录
            time.sleep(parms['SleepTime'])
    return errNum

# 收藏商品|取消收藏商品
def setFavouriteInfoByUser(logName, parms, productCode, operFlay=1, epg = ''):
    apiCode = '[120]'
    if epg == 'epg5':
        url = 'http://%s/ums_api/user!setFavouriteInfoByUserV2' % parms['UMS']
    else:
        url = 'http://%s/ums_api/user!setFavouriteInfoByUser' % parms['UMS']
    url += '?userCode=%s&serviceComboCode=%s' % (parms['UserCode'], parms['ServiceComboCode'])
    url += '&serviceGroupCode=%s&productCode=%s&operFlag=%s' % (parms['ServiceGroupCode'], productCode, operFlay)
    url += common.getRandom()  # 获取随机参数
    ret = common.get_url(parms, url, apiCode, logName)
    return ret

# 收藏记录查询
def getFavouriteInfoByUser(logName, parms, productCode = '', retcode = '', epg = ''):
    apiCode = '[121]'
    if epg == 'epg5':
        url = 'http://%s/ums_api/user!getFavouriteInfoByUserV2' % parms['UMS']
        listName = 'productList'
    else:
        url = 'http://%s/ums_api/user!getFavouriteInfoByUser' % parms['UMS']
        listName = 'listInfo'
    url += '?userCode=%s&pageLimit=20&pageNum=0' % parms['UserCode']
    url += '&serviceComboCode=%s&serviceGroupCode=%s' % (parms['ServiceComboCode'], parms['ServiceGroupCode'])
    url += common.getRandom()  # 获取随机参数
    if productCode == '':
        ret = common.get_url(parms, url, apiCode, logName, 1, retcode)
    else:
        ret = common.get_url(parms, url, apiCode, logName, 2, retcode, 'productCode', productCode, listName)
    return ret

# 删除用户所有收藏商品
def setDelFavouriteInfoByUser(logName, parms, epg = ''):
    apiCode = '[122]'
    if epg == 'epg5':
        url = 'http://%s/ums_api/user!setDelFavouriteInfoByUserV2' % parms['UMS']
    else:
        url = 'http://%s/ums_api/user!setDelFavouriteInfoByUser' % parms['UMS']
    url += '?userCode=%s' % parms['UserCode']
    url += '&serviceComboCode=%s&serviceGroupCode=%s' % (parms['ServiceComboCode'], parms['ServiceGroupCode'])
    url += common.getRandom()  # 获取随机参数
    ret = common.get_url(parms, url, apiCode, logName)
    return ret

# 查询用户是否收藏某一节目集
def getProductIsFavourite(logName, parms, productCode, count = '', epg = ''):
    apiCode = '[123]'
    if epg == 'epg5':
        url = 'http://%s/ums_api/user!getProductIsFavouriteV2' % parms['UMS']
    else:
        url = 'http://%s/ums_api/user!getProductIsFavourite' % parms['UMS']
    url += '?userCode=%s&productCode=%s' % (parms['UserCode'], productCode)
    url += '&serviceComboCode=%s&serviceGroupCode=%s' % (parms['ServiceComboCode'],parms['ServiceGroupCode'])
    url += common.getRandom()  # 获取随机参数
    ret = common.get_url(parms, url, apiCode, logName, 3, '', 'isFavorite', count)
    return ret

# 记录播放历史信息
def setPlayHistoryInfoByUser(logName, parms, productCode, seriesName, pictureUrl, playUrl):
    apiCode = '[124]'
    url = 'http://%s/ums_api/user!setPlayHistoryInfoByUser?userCode=%s' % (parms['UMS'], parms['UserCode'])
    url += '&productCode=%s&pictureUrl=%s&playUrl=%s&' % (productCode, pictureUrl.encode('utf-8'), playUrl)
    url += '&serviceComboCode=%s&playPoint=1' % parms['ServiceComboCode']
    str = {'seriesName': seriesName, 'playPoint': 0, 'volumnCount': 1}
    url += urllib.parse.urlencode(str)
    url += common.getRandom()  # 获取随机参数
    ret = common.get_url(parms, url, apiCode, logName)
    return ret

# 播放历史查询
def getPlayHistoryInfoByUser(logName, parms, productCode='', type=1, retcode=''):
    apiCode = '[125]'
    url = 'http://%s/ums_api/user!getPlayHistoryInfoByUser?userCode=%s&pageLimit=100&pageNum=0' % (parms['UMS'], parms['UserCode'])
    url += '&serviceComboCode=%s' % parms['ServiceComboCode']
    url += common.getRandom()  # 获取随机参数
    if type == 1:
        ret = common.get_url(parms, url, apiCode, logName, 2, retcode, 'productCode', productCode)
    elif type == 2:
        ret = common.get_url(parms, url, apiCode, logName, 5, retcode, 'productCode')
    elif type == 3:
        ret = common.get_url(parms, url, apiCode, logName, 1, retcode)
    else:
        ret = '4'
    return ret

# 删除播放历史信息
def deletePlayHistoryInfo(logName, parms, productCode = ''):
    apiCode = '[126]'
    if productCode == '':
        productCode = getPlayHistoryInfoByUser(logName, parms, productCode, 2)
    url = 'http://%s/ums_api/user!deletePlayHistoryInfo?userCode=%s&productCode=%s' % (parms['UMS'], parms['UserCode'], productCode)
    url += '&serviceComboCode=%s' % parms['ServiceComboCode']
    url += common.getRandom()  # 获取随机参数
    ret = common.get_url(parms, url, apiCode, logName)
    return ret

#if config_api.GLOBAL_debugType == 1:
    #Favourite('SDYD')
    #PlayHistory('TEST', '2100097151120080000026160', '大闹天宫', 'http://images.ott.cibntv.net/2011/11/30/danaotiangong.jpg', 'http://danaotiangong.m3u8')