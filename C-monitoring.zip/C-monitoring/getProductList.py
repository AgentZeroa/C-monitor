#!/usr/bin/env python
# -*- coding: utf-8 -*-

import time
import config_api
import common
from getSeriesInfoByCode import getSeriesInfoByCode
from getRecommendList import getRecommendList

def getProductList(control_name, packageCodes = '', packageName = '', history = 1, url1 = '',is_zt = 'N', pageNum = 0, procuct_count = 1):
    errNum = '9'
    errCount = 0
    productCount = 0
    picMsg = ''
    logMsg = ''
    url = ''
    count = 0
    usearch = {'JSYD', 'JSYD5'}
    if is_zt == 'N':
        apiCode = '[106]'
        # 判断返回值中每个产品是否都有如下节点，且不能为空值
        pic_check = {'pictureUrl'}
        check_name = 'productName'
        check_code = 'productCode'
        c_list = {'action', check_name, check_code, 'itemCode'}
        logName = control_name + '_getProductList_log.txt'
        ptype = '栏目'
    else:
        # 专题包
        apiCode = '[105]'
        logName = control_name + '_getPackageInfoByCode_log.txt'
        ptype = '专题包'

    # 判断参数是否正确,如果在列表里，则可以开始拼装参数，发送url请求
    parms = common.getConfig(apiCode, logName, control_name)

    if not parms == '-1':
        # 拼装url
        if packageCodes == '':
            packageCodes = parms['PackageCode']
        url = 'http://%s/vod_api/assetList!getProductList?serviceGroupCode=%s' % (parms['VOD'], parms['ServiceGroupCode'])
        url += '&packageCodes=%s&pageLimit=100&pageNum=%s&isAll=1' % (packageCodes, pageNum)

        if not is_zt == 'N':
            apiCode = '[105]'  # 获取专题包(getProductList)
            ptype = '专题包'
            is_zt = 'Y'
            url = 'http://%s/vod_api/packageInfo!getPackageInfoByCode?serviceGroupCode=' % parms['VOD']
            url += '%s&packageCode=%s&pageLimit=100&pageNum=0' % (parms['ServiceGroupCode'], packageCodes)
            # 判断返回值中每个产品是否都有如下节点，且不能为空值
            pic_check = {'pictureUrl'}
            zt_pic_check = {'packagePictureUrl'}
            check_name = 'productName'
            check_code = 'productCode'
            c_list = {'action', check_name, check_code}
            logName = control_name + '_getPackageInfoByCode_log.txt'
        if packageName == parms['Category_zt']:
            apiCode = '[129]'   # 专题汇总（getPackageList）
            ptype = '专题汇总'
            is_zt = 'Y'
            url = 'http://%s/vod_api/assetList!getPackageList?serviceGroupCode=' % parms['VOD']
            url += '%s&packageCodes=%s' % (parms['ServiceGroupCode'], packageCodes)

        # 请求接口加随机数
        url += common.getRandom()  # 获取随机参数
        urlRet = common.getUrlRet(url, parms['LOGPath'] + logName)

        # 判断返回值code为200，则检查返回值内容是否正确
        if urlRet['code'] == 200 and 'read' in urlRet:
            if not packageName == '':
                logMsg += ptype + ': ' + packageName + '； '
            # 判断返回值是否正确
            data = urlRet['read']['retMsg']
            if type(data) == dict and 'count' in data and 'listInfo' in data and type(data['listInfo']) == list and data['count'] > 0 and len(data['listInfo']) > 0:
                productCount = data['count']
                logMsg += 'count: ' + str(productCount) + '； packageCodes:' + packageCodes + '； \n'
                if procuct_count > productCount:
                    errNum = '753'
                    logMsg += 'count小于设定的值： %s 。\n' % str(procuct_count)
                else:
                    logMsg += '抽查结果：'
                    for info in data['listInfo']:
                        count += 1
                        if count > config_api.GLOBAL_checkListNum:
                            break
                        if common.check_list(info, c_list, 3) and info['action'] in config_api.GLOBAL_action:
                            # 判断图片pictureUrl如果不存在，则记录productName，errCount+1
                            if not common.check_list(info, pic_check, 3):
                                picMsg += check_name + ': ' + info[check_name] + '\n'
                                errCount += 1
                            errNum = '0'
                            logMsg += check_code + ': ' + info[check_code] + '；'
                            logMsg += check_name + ':' + info[check_name] + '；action: ' + info['action'] + '\n'
                            # 如果是专题包，还需要判断背景图片是否存在, EPG5.0除外
                            if is_zt == 'Y':
                                if not (common.check_list(data, zt_pic_check, 3, 10) or parms['EPG'] == '5.0'):
                                    errNum = '750'
                                    break
                                if info['action'] == 'OPEN_SPECIAL_TEMPLATE_1':
                                    getProductList(control_name, info['packageCode'], info['packageName'], history, url, procuct_count=config_api.GLOBAL_ZTNum)
                            if info['action'] == 'OPEN_DETAIL':
                                # 获取节目集详情
                                if history == 0:
                                    isHistory = True
                                    history += 1
                                else:
                                    isHistory = False
                                getSeriesInfoByCode(control_name, info[check_code], isHistory, info[check_name], url)
                                time.sleep(parms['SleepTime'])
                                # 获取关联推荐
                                getRecommendList(control_name, info[check_code])
                                time.sleep(parms['SleepTime'])
                        else:
                            errNum = '751'
                            if common.check_list(info, {check_name}, 3):
                                logMsg = check_name + ': ' + info[check_name] + '\n'
                            break
                    # 如果有节目pictureUrl为空，则记录下来
                    if errCount > 0:
                        errNum = '752'
                        logMsg = '共有' + str(errCount) + '个产品缺少图片。\n'
                        logMsg += picMsg
            elif packageCodes == '2100130022233552311200191':
                errNum = '0'
                logMsg += '安徽移动推广特殊需求，挂空包。\n'
            else:
                errNum = '701'
                logMsg += 'count为0或listInfo为空或格式不符。\n'
        else:
            # 连接出现问题，获取错误码信息
            errNum = urlRet['code']
            if 'read' in urlRet:
                logMsg += str(urlRet['read'])
                if 'retCode' in urlRet['read'] and urlRet['read']['retCode'] == 'ES000002':
                    logMsg += '请检查包中的产品是否可以播放。'
        if not packageName == '':
            logMsg += '\n 包名：%s。\n' % packageName
        if not url1 == '':
            logMsg += '清上级入口缓存：' + url1 + config_api.GLOBAL_delete_redis + '\n'

        #写日志和发邮件的内容在这里组合
        if parms['NAME'] and parms['LOGPath']:
            ret = common.log_mail(parms['NAME'], apiCode, errNum, logMsg, url, parms['LOGPath'], logName, parms['dingding_token'])
            if ret != 1:
                errNum = '7'

        # 判断是否还需要继续检查
        pageNum += 1
        check_count = pageNum * parms['PageLimit']
        if productCount > check_count and config_api.GLOBAL_checkListNum > check_count:
            getProductList(control_name, packageCodes, packageName, history, url1, is_zt, pageNum)

    return errNum

#if config_api.GLOBAL_debugType == 1:
#    getProductList('SDYD')