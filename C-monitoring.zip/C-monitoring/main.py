# -*- coding: utf-8 -*-

from deviceAuth import *
from deviceInit import *
import getRecommendInfo
from getNavigationInfo import *
from getCategoryList import *
from getCommodityListBySerach import *
from getSeriesInfoByCode import *
from getBms import *
from check_apk import *
from getWallPaper import *
from getUMS import *
from getEPG5 import *
from seriesInfo import *

if __name__ == '__main__':
    # 支持JSYD / JSYD5 / SDYD / SDZX / AHYD / SCYD / FJLT / SZTW / ITV5 / TEST / TEST5 / GSDX / SXYX / LTEST / AHYD5 / SZTW5 / SHMG
    control_name = 'JSYD5'

    # deviceAuth(control_name)
    # deviceInit(control_name)
    # getRecommendInfo.getRecommendInfo(control_name, '1100070023666451782030226')
    # getRecommendInfo.getRecommendInfo(control_name, '1100070022112827139758818')
    # getNavigationInfo(control_name)
    # getCategoryList(control_name)
    # getCommodityListBySerach(control_name, 'GFCJ')
    # bms_main(control_name)
    # check_APK(control_name)
    # Favourite(control_name)
    #
    getRecommendInfo.getRecommendInfo5(control_name)
    # getWallPaper(control_name)
    # getTagList(control_name)
    # recommend_box(control_name)
    # blankBySerach(control_name)
    # searchTop(control_name)
    # seriesInfo(control_name)

    # getSeriesInfoByCode('AHYD', '2100140023523648323700303')
    #getSeriesInfoByCode('JSYD', '2100140023116490154890263'
    # getSeriesInfoByCode('ITV5', '2100010062378320370786732')
    # getSeriesInfoByCode('ITV5', '2100010062373246385535758')
    # getSeriesInfoByCode('ITV5', '2100010062034400481453235')
    #getSeriesInfoByCode('SCYD', '2100140023369120784600125')
    #getSeriesInfoByCode('FJLT', '2100010062373246271188278')
    #getSeriesInfoByCode('SDYD', '2100140022188143365480144')
    '''
    code_list ={
        '2100140023116490154890263',
        '2100140022815347041910022',
        '2100140022556166489780046',
        '2100140022556166487980029',
        '2100140160317110000773512',
        '2100140022388642777430030',
        '2100140022294799008850035',
        '2100140022291441794630053',
        '2100140022285086646970028',
        '2100140022204454845610078',
        '2100140022966764344320081',
        '2100140023635256535270017',
        '2100140022733510002150006',
        '2100140022392270425110910',
        '2100140022392270424910908',
        '2100140022392270424710906',
        '2100140023874075628680716',
        '2100140023147463766900166',
        '2100140022294799008850035',
        '2100140022285086646970028',
        '2100140022981131197460077'}
    for code in code_list:
        getSeriesInfoByCode('JSYD', code)
'''


