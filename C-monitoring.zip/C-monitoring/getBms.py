#!/usr/bin/env python
# -*- coding: utf-8 -*-

import common

def bms_main(control_name):
    errNum = '9'
    logMsg = ''
    pdurl = ''
    pcurl = ''
    olurl = ''
    apiCode = '[110]'
    logName = control_name + '_getProductPricing_log.txt'
    url = ''

    # 判断参数是否正确,如果在列表里，则可以开始拼装参数，发送url请求
    parms = common.getConfig(apiCode, logName, control_name)

    if not parms == '-1' and 'IsBMS' in parms and parms['IsBMS'] == 'Y':
        ip = parms['BMS']
        sgc = parms['ServiceGroupCode']
        pdc = parms['ProductCode']
        pcc = parms['PackageCode']
        scc = parms['ServiceComboCode']
        uc = parms['UserCode']
        mac = parms['MAC']
        at = parms['AuthType']
        ac = parms['AuthCode']
        tk = parms['Token']
        logpath = parms['LOGPath']
        name = parms['NAME']
        # 判断参数都存在
        if ip and pdc and pcc and at and ac and tk:
            # 拼装url
            pdurl = 'http://%s/bms_api/price!getProductPricing?serviceGroupCode=%s&productCode=%s' % (ip, sgc, pdc)
            pdurl += '&serviceComboCode=%s&authType=%s&authCode=%s&token=%s' % (scc, at, ac, tk)
            # 获取产品价签信息
            errNum = getProductPricing(control_name, pdurl, logpath, name)

            pcurl = 'http://%s/bms_api/price!getPackagePricing?serviceComboCode=%s&serviceGroupCode=%s' % (ip, scc, sgc)
            pcurl += '&packageCode=%s&authType=%s&authCode=%s&token=%s' % (pcc, at, ac, tk)
            # 获取产品包价签信息
            #getPackagePricing(control_name, pcurl, logpath, name)

            #olurl = 'http://%s/bms_api/order!getOrderList?userCode=%s&mac=%s&serviceComboCode=%s' % (ip, uc, mac, scc)
            # 获取用户订购列表
            #getOrderList(control_name, olurl, logpath, name)

        # 参数不在配置文件中
        else:
            errNum = '-1'
            # 写日志和发邮件的内容在这里组合
            common.log_mail(name, apiCode, errNum, logMsg, url, logpath, logName)

    return errNum

def getProductPricing(control_name, url, logPath, name):
    errNum = '9'
    logMsg = ''
    logName = control_name + '_getProductPricing_log.txt'
    apiCode = '[110]'    # 获取产品价签信息(getProductPricing)

    url += common.getRandom()  # 获取随机参数
    # 请求接口
    urlRet = common.getUrlRet(url, logPath + logName)

    # 判断返回值code为200，则检查返回值内容是否正确
    if urlRet['code'] == 200 and 'read' in urlRet and type(urlRet['read']) == dict and 'retInfo' in urlRet['read']:
        data = urlRet['read']['retInfo']
        # 判断返回值是否正确
        if type(data) == dict and 'packagePriceList' in data and type(data['packagePriceList']) == list and len(data['packagePriceList']) > 0:
            plist = data['packagePriceList'][0]
            if type(plist) == dict and 'packageCode' in plist and 'packageName' in plist:
                errNum = '0'
                logMsg += 'packageCode: ' + plist['packageCode'] + '；packageName:' + plist['packageName'] + '\n'
            else:
                errNum = '742'
        else:
            errNum = '701'
    else:
        # 连接出现问题，获取错误码信息
        errNum = urlRet['code']

    if not errNum == '0' and 'read' in urlRet:
        logMsg += str(urlRet['read'])

    # 写日志和发邮件的内容在这里组合
    ret = common.log_mail(name, apiCode, errNum, logMsg, url, logPath, logName)
    if ret != 1:
        errNum = '7'
    return errNum
'''
def getPackagePricing(control_name, url, logPath, name):
    errNum = '9'
    logMsg = ''
    logName = control_name + '_getPackagePricing_log.txt'
    apiName = '获取产品包价签信息(getPackagePricing)'

    url += common.getRandom()   # 获取随机参数
    # 请求接口
    urlRet = common.getUrlRet(url, logPath + logName)

    # 判断返回值code为200，则检查返回值内容是否正确
    if urlRet['code'] == 200 and 'read' in urlRet and 'retInfo' in urlRet['read']:
        data = urlRet['read']['retInfo']
        # 判断返回值是否正确
        if 'priceInfo' in data and len(data['priceInfo']) > 0:
            for list in data['priceInfo']:
                if 'priceCode' in list and 'priceName' in list:
                    errNum = '0'
                    logMsg += 'priceCode: ' + list['priceCode'] + '；priceName:' + list['priceName'] + '\n'
                else:
                    errNum = '741'
                    break
        else:
            errNum = '701'
    else:
        # 连接出现问题，获取错误码信息
        errNum = urlRet['code']

    if not errNum == '0' and 'read' in urlRet:
        logMsg += str(urlRet['read'])

    # 写日志和发邮件的内容在这里组合
    ret = common.log_mail(name, apiName, errNum, logMsg, url, logPath, logName)
    if ret != 1:
        errNum = '7'
    return errNum
'''
'''
def getOrderList(control_name, url, logPath, name):
    errNum = '9'
    logMsg = ''
    logName = control_name + '_getOrderList_log.txt'
    apiName = '获取用户订购列表(getOrderList)'

    url += common.getRandom()   # 获取随机参数
    # 请求接口
    urlRet = common.getUrlRet(url, logPath + logName)

    # 判断返回值code为200，则检查返回值内容是否正确
    if urlRet['code'] == 200 and 'read' in urlRet and 'retInfo' in urlRet['read']:
        data = urlRet['read']['retInfo']
        # 判断返回值是否正确
        if 'orderList' in data and len(data['orderList']) > 0:
            for list in data['orderList']:
                if 'assetCode' in list and 'assetName' in list:
                    errNum = '0'
                    logMsg += 'assetCode: ' + list['assetCode'] + '；assetName:' + list['assetName'] + '\n'
                else:
                    errNum = '740'
                    break
        else:
            errNum = '701'
    else:
        # 连接出现问题，获取错误码信息
        errNum = urlRet['code']

    if not errNum == '0' and 'read' in urlRet:
        logMsg += str(urlRet['read'])

    # 写日志和发邮件的内容在这里组合
    ret = common.log_mail(name, apiName, errNum, logMsg, url, logPath, logName)
    if ret != 1:
        errNum = '7'
    return errNum
'''

# if config_api.GLOBAL_debugType == 1:
#    ret = bms_main('JS4K')