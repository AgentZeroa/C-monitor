# -*- coding: utf-8 -*-
import common
import time

msg = '服务器心跳测试。'
msg += time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
common.sendWeiXin(msg)

