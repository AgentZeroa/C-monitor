# -*- coding: utf-8 -*-

import time
import config_api
import common
from getProductList import getProductList
from getPackageList import getPackageList

def getCategoryList(control_name, category_code = ''):
    errNum = '9'
    producNum = '0'
    logMsg = ''
    url = ''
    logName = control_name+'_getCategoryList_log.txt'
    apiCode = '[104]'
    n = 0

    packageCode_list_1 = {}
    packageCode_list_2 = {}

    # 判断参数是否正确,如果在列表里，则可以开始拼装参数，发送url请求
    parms = common.getConfig(apiCode, logName, control_name)

    if not parms == '-1':
        c_list = {'categoryCode': parms['CategoryCode'], 'name': parms['CategoryName']}
        #拼装url
        url = 'http://%s/vod_api/category!getCategoryList?serviceGroupCode=%s' % (parms['VOD'], parms['ServiceGroupCode'])
        url += common.getRandom()  # 获取随机参数

        #请求接口
        urlRet = common.getUrlRet(url, parms['LOGPath'] + logName)

        # 判断返回值code为200，则检查返回值内容是否正确
        if urlRet['code'] == 200 and 'retMsg' in urlRet['read'] and type(urlRet['read']['retMsg']) == list:
            # 判断返回值是否正确
            for category in urlRet['read']['retMsg']:
                category_list = []
                # 判断返回结果格式及level和categoryItem是否存在
                if type(category) == dict and 'level' in category and 'categoryItem' in category and type(category['categoryItem']) == list:
                    if category['level'] == '0' and category_code == '':
                        # 判断categoryCode和name是否正确
                        if common.check_list(category['categoryItem'][0], c_list):
                            continue
                        else:
                            errNum = '711'
                            logMsg += '预期返回categoryCode：%s； CategoryName：%s； ' % (parms['CategoryCode'], parms['CategoryName'])
                            break
                    elif category['level'] == '1':
                        # 获取categoryCode，计算packageCodes下的包数量，按{'code':'num','code':'num'}记录到packageCode_list_1中
                        category_list = getList_1(category['categoryItem'])
                        # 判断category_code 如果存在一级栏目中，返回True，反之返回False
                        if not category_code == '' and category_code in category_list['name']:
                            return True
                        elif not category_code == '':
                            continue
                        errNum = category_list['errNum']
                        if errNum == '0':
                            packageCode_list_1 = category_list['list']
                            packageCode_name = category_list['name']
                            # 调用获取列表页产品包的接口
                            if producNum == '0' or producNum['errNum'] == '0':
                                producNum = produc_list(control_name, category['categoryItem'], n, url, parms['Category_zt'])
                                n += 1
                                time.sleep(parms['SleepTime'])
                        else:
                            break
                    # 轮循的时候不需要遍历二级栏目
                    elif category['level'] == '2' and not config_api.GLOBAL_debugType == 3:
                        if not category_code == '':
                            cCode = getCategotyCode(category['categoryItem'])
                            if type(cCode) == list and category_code in cCode:
                                return True
                            else:
                                continue
                        else:
                            # 调用获取列表页产品包的接口
                            if producNum == '0' or producNum['errNum'] == '0':
                                producNum = produc_list(control_name, category['categoryItem'], n, url)
                                time.sleep(parms['SleepTime'])
                            # 判断parentCode，把一个parentCode的栏目packageCodes下的包按{parentCode:['code1','code2']}，记录到packageCode_list_2中
                            category_list = getList_2(category)
                            errNum = category_list['errNum']
                            parent = category_list['parent']
                            logMsg += category_list['errMsg']
                            if parent in packageCode_list_1 and errNum == '0':
                                if parent in packageCode_list_2:
                                    packageCode_list_2[parent] = packageCode_list_2[parent] + category_list['code']
                                else:
                                    packageCode_list_2[parent] = category_list['code']
                            elif errNum == '0':
                                errNum = '719'
                                logMsg += 'parentCode:' + parent
                                if 'name' in category['categoryItem'][0]:
                                    logMsg += '； name:' + category['categoryItem'][0]['name'] + '\n'
                                break
                            else:
                                break
                    elif not category_code == '':
                        continue
                    elif config_api.GLOBAL_debugType == 3:
                        continue
                    else:
                        errNum = '715'
                        logMsg += 'level:' + category['level'] + '\n'
                        break
                else:
                    errNum = '709'
                    logMsg += category + '\n'
                    break

                # if not producNum['errNum'] == '0':
                #     # errNum = producNum['errNum']
                #     logMsg += producNum['errMsg']
                #     break
            # 判断packageCode_list__1和packageCode_list__2中的数是否相等
            if errNum == '0':
                check = check_num(packageCode_list_1, packageCode_list_2)
                errNum = check['errNum']
                categoryNum = len(check['packageCode'])

                if errNum == '0':
                    logMsg += '一级栏目:' + str(packageCode_name) + '\n'
                    logMsg = '一级栏目数量为：' + str(categoryNum) + ' 个(包括专题)。\n' + logMsg + '\n'
                else:
                    logMsg += '一级栏目:' + str(check['packageCode']) + '。\n'

                if 'errMsg' in check:
                    logMsg += check['errMsg'] + '\n'
        else:
            # 连接出现问题，获取错误码信息
            errNum = urlRet['code']
            logMsg += str(urlRet['read']) + '\n'

        if type(urlRet['read']) == dict and 'read' in urlRet and 'retCode' in urlRet['read'] and not errNum == '0':
            logMsg += 'retCode:' + urlRet['read']['retCode'] + '\n'
        elif 'read' in urlRet and not errNum == '0':
            logMsg += 'retCode:' + str(urlRet['read']) + '\n'

    # 参数不在配置文件中，无法写日志
    else:
        errNum = '4'
        return errNum

    # 写日志和发邮件的内容在这里组合
    if not parms == '-1' and parms['NAME'] and parms['LOGPath']:
        ret = common.log_mail(parms['NAME'], apiCode, errNum, logMsg, url, parms['LOGPath'], logName)
        if ret != 1:
            errNum = '7'

    return errNum

# 返回一级栏目的{'errNum':'0','list':{'code':count,'code1':count1},'name':{'code':'name}}
def getList_1(category):
    ret = {'errNum': '9', 'list': {}, 'name': {}}
    for packageCode in category:
        package_list = packageCode['packageCodes']
        package_name = packageCode['name']
        ret['name'][packageCode['categoryCode']] = package_name
        package_count = len(package_list.rsplit(','))
        if package_count > 0:
            ret['list'][packageCode['categoryCode']] = package_count
            errNum = '0'
        else:
            errNum = '712'
            break
    ret['errNum'] = errNum
    return ret

# 返回二级栏目的{'errNum':'0','parent':'2100050022393929906331445','code':['code1','code2']}
def getList_2(category):
    ret = {'errNum': '9', 'code': []}
    ret['parent'] = category['parentCode']
    ret['errMsg'] = ''
    for categoryItem in category['categoryItem']:
        packageCodes = categoryItem['packageCodes'].rsplit(',')
        if len(categoryItem['packageCodes']) >= 1 and categoryItem['parentCode'] == ret['parent']:
            ret['code'] = ret['code'] + packageCodes
            errNum = '0'
        elif len(categoryItem['packageCodes']) >= 1:
            errNum = '717'
            ret['errMsg'] = 'parentCode: ' + categoryItem['parentCode'] + '\n'
            if 'name' in categoryItem:
                ret['errMsg'] += '二级栏目名：' + categoryItem['name'] + '； parentCode: ' + ret['parent'] + '\n'
            break
        else:
            errNum = '713'
            if 'name' in categoryItem:
                ret['errMsg'] = '二级栏目名：' + categoryItem['name'] + '\n'
            if 'parentCode' in categoryItem:
                ret['errMsg'] += 'parentCode：' + categoryItem['parentCode'] + '\n'
            break
    ret['errNum'] = errNum
    return ret

# 返回{'errNum': '712', 'packageCode':'errCode', 'errMsg': '一级栏目包数量——对应二级栏目包数量'}
# 返回{'errNum': '0', 'packageCode':['code1','code2']}
def check_num(packageCode_list_1, packageCode_list_2):
    ret = {'errNum': '9', 'packageCode': []}
    zt = 0
    for key in packageCode_list_1:
        if key in packageCode_list_2:
            # 相等正确
            key_2 = set(packageCode_list_2[key])
            if packageCode_list_1[key] == len(key_2):
                ret['errNum'] = '0'
                ret['packageCode'].append(key)
            else:
                ret['errNum'] = '716'
                # ret['packageCode'].append(key)
                ret['packageCode'] = key
                ret['errMsg'] = '一级栏目下产品包数量：' + str(packageCode_list_1[key])
                ret['errMsg'] += '； 该一级栏目下所有二级栏目的产品包总数：' + str(len(key_2))
                break
        elif packageCode_list_1[key] == 0:
            ret['errNum'] = '712'
            ret['packageCode'] = key
            break
        elif zt < 1:
            # 排除专题没有二级栏目，如果还有一级栏目没有子栏目，则错误
            zt += 1
            ret['packageCode'].append(key)
        else:
            ret['errNum'] = '714'
            ret['packageCode'] = key
            break
    return ret

def produc_list(control_name,categoryItem, n=1, url1='', zt_name=''):
    ret = {}
    ret['errMsg'] = ''
    errNum = '9'
    for category in categoryItem:
        check_list = {'name', 'packageCodes', 'categoryCode'}
        if common.check_list(category, check_list, 3):
            # 全部专题调用专题汇总接口
            if category['name'] == zt_name:
                errNum = getPackageList(control_name, category['packageCodes'], category['name'], url1)
            # 其他栏目调用获取列表页产品包接口
            else:
                errNum = getProductList(control_name, category['packageCodes'], category['name'], n, url1)
            ret['errMsg'] = 'name: ' + category['name'] + '\n'
            n += 1
        elif 'name' in category:
            errNum = '718'
            ret['errMsg'] = 'name: ' + category['name'] + '\n'
            break
        else:
            errNum = '718'
            ret['errMsg'] = 'name不存在.\n'
            break
    ret['errNum'] = errNum
    return ret

def getCategotyCode(data):
    ret = []
    for categotyItem in data:
        if type(categotyItem) == dict and 'categoryCode' in categotyItem and len(categotyItem['categoryCode']) > 0:
            ret.append(categotyItem['categoryCode'])
        else:
            return False
    return ret

# if config_api.GLOBAL_debugType == 1:
#    getCategoryList('SDZX')





