# -*- coding: UTF-8 -*-

import config_api
import common
import time
import http.client


def check_APK(control_name):
    errNum = '9'
    url = ''
    logMsg = ''
    logName = control_name + '_check_apk_log.txt'
    apiCode = '[111]'    # 判断APK是否存在:

    # 判断参数是否正确,如果在列表里，则可以开始拼装参数，发送url请求
    parms = common.getConfig(apiCode, logName, control_name)

    if not parms == '-1' and parms['APK'] and parms['APK_URL'] and parms['APK_PORT']:
        ip = parms['APK']
        port = parms['APK_PORT']
        timeout =config_api.GLOBAL_setTimeOut
        url = parms['APK_URL']
        conn = http.client.HTTPConnection(ip, port, timeout)
        conn.request('GET', url)
        response = conn.getresponse()
        conn.close()
        #print(response.status, response.reason)
        url = 'http://' + ip + ':' + port + url
        if response.status == 200:
            errNum = "0"
            logMsg += "APK文件存在，可以下载。\n"
        else:
            errNum = '700'
            #print(response.status)
            logMsg += 'APK文件不存在，请检查' + url +'\n'
    elif parms == '-1':
        errNum = '-1'
    else:
        return

    # 写日志和发邮件的内容在这里组合
    if not parms == '-1' and parms['NAME'] and parms['LOGPath']:
        ret = common.log_mail(parms['NAME'], apiCode, errNum, logMsg, url, parms['LOGPath'], logName)
        if ret != 1:
           errNum = '7'

    return errNum


# if config_api.GLOBAL_debugType == 1:
#    check_APK('SDYD')