#!/usr/bin/env python
# -*- coding: utf-8 -*-

import time
import config_api
import common
import getRecommendInfo

def getNavigationInfo(control_name):
    errNum = '9'
    url = ''
    logName = control_name + '_getNavigationInfo_log.txt'
    apiCode = '[103]'
    logMsg = ''
    # 判断关键节点是否存在
    n_list = {'navigationCode', 'navigationItem'}           # retMsg下必须存在的节点，且不能为空值
    c_list = {'code', 'name', 'action', 'recommendCode'}    # retMsg['navigationItem']下必须存在的节点，且不能为空值

    # 判断参数是否正确,如果在列表里，则可以开始拼装参数，发送url请求
    parms = common.getConfig(apiCode, logName, control_name)

    if not parms == '-1' and parms['NavigationCode'] and parms['NavigationItemCode'] and parms['NavigationName']:
        errNum = '9'
        # 拼装url
        url = 'http://%s/oms_api/serviceGroup!getNavigationInfo?serviceComboCode=%s' % (parms['OMS'], parms['ServiceComboCode'])
        url += common.getRandom()  # 获取随机参数

        # 请求接口
        urlRet = common.getUrlRet(url,parms['LOGPath'] + logName)

        # 判断返回值code为200，则检查返回值内容是否正确
        if urlRet['code'] == 200 and 'retMsg' in urlRet['read'] and type(urlRet['read']['retMsg']) == dict:
            data = urlRet['read']['retMsg']
            # 判断返回值是否正确
            if common.check_list(data, n_list, 3) and data['navigationCode'] == parms['NavigationCode'] and type(data['navigationItem']) == list:
                logMsg += '获取全局导航navigationCode：' + data['navigationCode'] + '\n'
                for navi in data['navigationItem']:
                    if common.check_list(navi, c_list, 2) and navi['name'] in parms['NavigationName'] and navi['code'] in parms['NavigationItemCode']:
                        logMsg += 'code: ' + navi['code'] + '；name: ' + navi['name'] + '； action: '
                        logMsg += navi['action'] + '； recommendCode: ' + navi['recommendCode'] + '\n'
                        if navi['action'] == '' or navi['action'] in config_api.GLOBAL_action:
                            errNum = '0'
                            if navi['action'] == 'OPEN_PROGRAM_LIST' and not ('EPG' in parms and parms['EPG'] == '5.0'):
                                # 调取EPG4.0推荐位
                                getRecommendInfo.getRecommendInfo(control_name, navi['recommendCode'])
                                time.sleep(parms['SleepTime'])
                        else:
                            errNum = '703'
                            logMsg += 'action：' + navi['action'] + '\n'
                            break
                    elif common.check_list(navi, c_list, 3):
                        errNum = '721'
                        logMsg += 'name：' + navi['name'] + '；code：' + navi['code'] + '\n'
                        break
                    else:
                        errNum = '722'
                        logMsg += str(navi) + '\n'
                        break
                if parms['EPG'] == '5.0':
                    # 调取EPG5.0推荐位
                    getRecommendInfo.getRecommendInfo5(control_name)
                    time.sleep(parms['SleepTime'])

            elif common.check_list(data, n_list, 2):
                errNum = '720'
                logMsg += '预期返回navigationCode：' + parms['NavigationCode'] + '\n'
                logMsg += '实际返回navigationCode：' + data['navigationCode'] + '\n'
            else:
                errNum = '723'
        else:
            # 连接出现问题，获取错误码信息
            errNum = urlRet['code']

            if 'read' in urlRet:
                logMsg += str(urlRet['read'])
    else:
        errNum = '-1'

    # 写日志和发邮件的内容在这里组合
    if not parms == '-1' and parms['NAME'] and parms['LOGPath']:
        ret = common.log_mail(parms['NAME'], apiCode, errNum, logMsg, url, parms['LOGPath'], logName)
        if ret != 1:
            errNum = '7'

    return errNum

# if config_api.GLOBAL_debugType == 1:
#     getNavigationInfo('SCYD')
