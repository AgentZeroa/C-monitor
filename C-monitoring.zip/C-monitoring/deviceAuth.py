#!/usr/bin/env python
# -*- coding: utf-8 -*-

import common

def deviceAuth(control_name):
    errNum = '9'
    url = ''
    logMsg = ''
    logName = control_name+'_Auth_log.txt'
    apiCode = '[101]'

    # 判断参数是否正确,如果在列表里，则可以开始拼装参数，发送url请求
    parms = common.getConfig(apiCode, logName, control_name)

    if not parms == '-1':
        # 拼装url
        url = 'http://%s/oms_api/device!deviceAuth?mac=%s' % (parms['OMS'], parms['MAC'])
        if parms['InitType'] == 'front':
            url += '&agentCode=%s&comboCode=%s' % (parms['AgentCode'], parms['ServiceComboCode'])
        url += common.getRandom()  # 获取随机参数

        errNum = common.get_url(parms, url, apiCode, logName, 4, '', 'retMsg', parms['ServiceComboCode'])

    return errNum

# if config_api.GLOBAL_debugType == 1:
#     deviceAuth('SCYD')