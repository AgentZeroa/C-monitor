#!/usr/bin/env python
# -*- coding: utf-8 -*-
# '[107]': '获取节目集详情

import config_api
import common
import getUMS
import time
# from unifiedSearch import unifiedSearch

def getSeriesInfoByCode(control_name, productCode = '', isHistory = False, Name = '', url1=''):
    errNum = '9'
    logPath = './'
    logMsg = ''
    miss = '0'
    logName = control_name+'_getSeriesInfoByCode_log.txt'
    apiCode = '[107]'       #节目集详情
    currentNum = 'currentNum'  # 更新集数字段
    volumnCount = 'volumnCount'  # 节目集总集数
    programList = 'programList'  # 节目集信息字段
    seriesName = 'seriesName'   # 节目集名称
    programCount = 'programCount'   # 节目集实际集数
    releaseYear = 'releaseYear'     # 发行年代
    originalCountry = 'originalCountry'     # 地区
    cpName = 'cpName'   # CP名
    proType = 'programType' # 一级分类
    programType = {'电影', '电视剧', '综艺', '动漫', '少儿', '纪录片'}  # 需要进行缺集校验的类型
    pinyinsuoxie = 'pinyinsuoxie'   # 拼音缩写
    usearch = {'JSYD', 'JSYD5'}

    # 判断各层关键节点是否存在
    c_list = {'seriesCode', seriesName, programList, 'pictureurl1', 'programCount'}
    count_list = {volumnCount, currentNum, cpName, proType, releaseYear, originalCountry}
    p_list = {'action', 'programName', 'programCode', 'movieList', 'programSequence'}

    # 判断参数是否正确,如果在列表里，则可以开始拼装参数，发送url请求
    parms = common.getConfig(apiCode, logName, control_name)

    if not parms == '-1':
        if not Name == '':
            logMsg = 'seriesName: ' + Name + '； '
        # 拼装url
        if productCode == '':
            productCode = parms['ProductCode']
        url = 'http://%s/vod_api/seriesInfo!getSeriesInfoByCode?domainCodes=%s&serviceGroupCode=%s' % (parms['VOD'], parms['DomainCodes'], parms['ServiceGroupCode'])
        url += '&userCode=%s&productCode=%s' % (parms['UserCode'], productCode)
        url += common.getRandom()  # 获取随机参数

        # 请求接口
        urlRet = common.getUrlRet(url, parms['LOGPath'] + logName)

        # 判断返回值code为200，则检查返回值内容是否正确
        if urlRet['code'] == 200 and 'retMsg' in urlRet['read']:
            data = urlRet['read']['retMsg']
            # 判断返回值是否正确
            if type(data) == dict and common.check_Len(data, programCount, 0, 3):
                # 判断关键节点是否正确
                if common.check_list(data, c_list, 3) and common.check_list(data, count_list, 2) and type(data['programList']) == list:
                    if Name == '':
                        logMsg = 'seriesName: ' + data[seriesName] + '； '
                    logMsg += 'programType：' + data[proType] + '； '
                    logMsg += ' seriesCode: ' + data['seriesCode'] + '；\n'
                    errMsg = data[seriesName] + '\t' + data[proType] + '\t' + data[cpName] + '\t'
                    errMsg += data[releaseYear] + '\t' + data[originalCountry] + '\t' + data['seriesCode'] + '\t'
                    # 判断总集数和实际集数是否相符,查缺集不告警，只写日志。
                    #print(parms['miss_set'])
                    if parms['miss_set']:
                        miss_set_list = common.get_text_to_list(config_api.GLOBAL_rootLogPath + parms['miss_set'])
                        # 如果是不需要判断的节目集，则跳过
                        #print(miss_set_list)
                        if data['seriesCode'] in miss_set_list or data['id'] in miss_set_list:
                            miss = '1'
                    if data[proType] in programType and miss == '0':
                        check_program = check_program_count(data[programList], abs(data[volumnCount]), abs(data[currentNum]), data[programCount])
                        if not check_program['Code'] == '0':
                            volumnCountMsg = errMsg + check_program['logMsg']
                            path = parms['LOGPath'] + control_name + '_' + config_api.GLOBAL_missSetLog
                            common.writeLog(path, volumnCountMsg, 2)
                            #print(volumnCountMsg)
                    programList = data['programList'][0]
                    '''
                    # 统一搜索版本
                    if config_api.GLOBAL_debugType in {1, 5} and pinyinsuoxie in data and control_name in usearch:
                        search = data[pinyinsuoxie].split()[-1]
                        sName = data[seriesName]
                        spaces = len(sName.split()[0])
                        if(len(search) > spaces):
                            search = search[:spaces] + '%20' + search[spaces:]
                        unifiedSearch(control_name, search, sName)
                    '''
                    # 判断关键节点是否正确
                    if common.check_list(programList, p_list, 2) and type(programList['movieList']) == list and 'movieUrl' in programList['movieList'][0]:

                        # 接口返回剧集编号为0，不告警，只写日志。
                        if int(programList['programSequence']) <= 0:
                            SequenceMsg = errMsg + '出现剧集编号为：%s 的异常。' % programList['programSequence'] + '\n'
                            #SequenceMsg += url + '\n'
                            path = parms['LOGPath'] + control_name + '_' + config_api.GLOBAL_errSequenceLog
                            common.writeLog(path, SequenceMsg, 2)
                            # print(SequenceMsg)

                        logMsg += 'programName: ' + programList['programName']
                        logMsg += '； action: ' + programList['action'] + '\n'
                        logMsg += 'movieUrl:' + programList['movieList'][0]['movieUrl'] + '\n'
                        if programList['action'] in config_api.GLOBAL_action:
                            if len(programList['movieList'][0]['movieUrl']) >= 10:
                                errNum = '0'
                            else:
                                errNum = '735'
                        else:
                            errNum = '703'
                            logMsg += '实际返回action：' + programList['action'] + '\n'

                        # 调用收藏和播放记录的接口
                        if isHistory:
                            if parms['EPG'] == '5.0':
                                epg = 'epg5'
                            else:
                                epg = ''
                            getUMS.Favourite(control_name, productCode, epg)
                            # getUMS.PlayHistory(control_name, productCode, data['seriesName'], data['pictureurl1'], programList['movieList'][0]['movieUrl'])
                    else:
                        errNum = '731'
                        if common.check_list(data, {'programName'}, 3):
                            logMsg += 'programName: ' + data['programName']
                        logMsg += str(programList) + '\n'
                else:
                    errNum = '732'
            elif 'programCount' in data:
                errNum = '733'
                logMsg += 'programCount：' + data['programCount'] + '\n'
            else:
                errNum = '734'
        else:
            # 连接出现问题，获取错误码信息
            errNum = urlRet['code']
        if not url1 == '':
            if control_name == 'ITV5' and 'recommend5' in url1:
                logMsg += '上级入口推荐位，清缓存需要运维同学操作。 \n'
            else:
                logMsg += '清上级入口缓存：' + url1 + config_api.GLOBAL_delete_redis + '\n'
        if not errNum == '0' and type(urlRet['read']) == dict and 'read' in urlRet and 'retCode' in urlRet['read'] and 'retMsg' in urlRet['read']:
            logMsg += 'retCode:' + urlRet['read']['retCode']
            if seriesName in urlRet['read']['retMsg']:
                logMsg += '； seriesName：' + urlRet['read']['retMsg'][seriesName]
            else:
                logMsg += '; retMsg:' + urlRet['read']['retMsg']
            if 'programType' in urlRet['read']['retMsg']:
                logMsg += '； programType：' + urlRet['read']['retMsg']['programType']
        elif not errNum == '0' and 'read' in urlRet:
            logMsg += str(urlRet['read']) + '\n'

    #写日志和发邮件的内容在这里组合
    if not parms == '-1' and parms['NAME'] and parms['LOGPath']:
        ret = common.log_mail(parms['NAME'], apiCode, errNum, logMsg, url, parms['LOGPath'], logName, parms['dingding_token'])
        if ret != 1:
            errNum = '7'

    return errNum

# 查缺集、重复集数
def check_program_count(programList, total, currentNum, programCount):
    list = []
    ret = {}
    ret['Code'] = '0'
    ret['logMsg'] = ''
    lostNum = 0
    lostMsg = '缺少：'
    recurringNum = 0
    recurringMsg = '重复出现：'
    programSequence = 'programSequence'
    #获取当前日期
    today = time.strftime("%Y%m%d")
    # 如果更新集数为日期格式，且更新时间在两周之内，则认为是跟播剧
    if currentNum > 20000 and currentNum > (int(today) - 14):
        total = len(programList)
    elif currentNum < total or total == 0:    # 如果更新集数小于总集数，或总集数为0则认为是跟播剧
        total = currentNum
    # 将programSequence字段值取出放入list
    for program in programList:
        if programSequence in program and int(program[programSequence]) < 20000:
            list.append(int(program[programSequence]))
        elif programSequence in program and total == programCount:
            ret['Code'] = '0'
            ret['logMsg'] = '期数为日期格式，数量符合。\t'
            break
        elif programSequence in program and currentNum == programCount:
            ret['Code'] = '-1'
            ret['logMsg'] = '期数为日期格式，更新集数符合，但总集数：%s，小于更新集数：%s。\t' % (total, currentNum)
            break
        elif programSequence in program:
            ret['Code'] = '-1'
            ret['logMsg'] = '期数为日期格式，总集数为：%s，更新集数为：%s，实际集数为%s。\t' % (total, currentNum, programCount)
        else:
            ret['Code'] = '-1'
            ret['logMsg'] = '集数字段丢失或错误。\t'
            break
    # 判断list里是否缺少或重复
    if not ret['Code'] == '-1' and len(list) > 0:
        for i in range(1, int(total)+1):
            count = list.count(i)
            if count == 0:
                lostMsg += '第%s集；' % i
                lostNum += 1
            elif count > 1:
                recurringMsg += '第%s集%s次；' % (i, count)
                recurringNum += 1
        if recurringNum > 0:
            ret['logMsg'] += recurringMsg + '\t'
            ret['Code'] = '2'
        if lostNum > 0:
            ret['logMsg'] += lostMsg + '\t'
            ret['Code'] = '1'
    ret['logMsg'] += '\n'
    return ret


#if config_api.GLOBAL_debugType == 1:
#   getSeriesInfoByCode('TEST')