#!/usr/bin/env python
# -*- coding: utf-8 -*-

import config_api
import common

def getRecommendList(control_name, productCode = ''):
    errNum = '9'
    logMsg = ''
    errCount = 0
    picMsg = ''
    count = 0
    logName = control_name+'_getRecommendList_log.txt'
    apiCode = '[109]'   # 关联推荐(getRecommendList)
    # 判断关键节点是否存在
    c_list = {'action', 'productCode', 'itemCode', 'productName'}
    d_list = {'count', 'listInfo'}

    # 判断参数是否正确,如果在列表里，则可以开始拼装参数，发送url请求
    parms = common.getConfig(apiCode, logName, control_name)

    if not parms == '-1':
        # 拼装url
        if productCode == '':
            productCode = config_api.CONTROL_NAME[control_name]['ProductCode']
        url = 'http://%s/vod_api/commodityList!getRecommendList?serviceGroupCode=%s&productCode=%s' % (parms['VOD'], parms['ServiceGroupCode'], productCode)
        url += '&packageCodes=&userCode=%s&packageCode=&commodityType=2&recommendType=2' % (parms['UserCode'])
        url += common.getRandom()  # 获取随机参数

        # 请求接口
        urlRet = common.getUrlRet(url,parms['LOGPath'] + logName)

        # 判断返回值code为200，则检查返回值内容是否正确
        if urlRet['code'] == 200:
            data = urlRet['read']['retMsg']
            # 判断返回值是否正确
            if type(data) == dict and common.check_list(data, d_list, 3) and data['count'] > 0 and type(data['listInfo']) == list and len(data['listInfo']) > 0:
                logMsg += 'count: ' + str(data['count']) + '\n'
                for info in data['listInfo']:
                    count += 1
                    if count > config_api.GLOBAL_checkListNum:
                        break
                    if common.check_list(info, c_list, 3) and info['action'] in config_api.GLOBAL_action:
                        errNum = '0'
                        logMsg += 'productCode: ' + info['productCode'] + '；itemCode:' + info['itemCode'] + '；productName:' + info['productName'] + '；action: ' + info['action'] + '\n'
                    else:
                        errNum = '751'
                        break
                    if not common.check_list(info, {'pictureUrl'}, 3):
                        errCount += 1
                        picMsg += '%s.%s； ' % (errCount, info['productName'])
                # 如果有节目pictureUrl为空，则记录下来
                if errCount > 0:
                    errNum = '752'
                    logMsg = '共有' + str(errCount) + '个产品缺少图片。 productName： \n'
                    logMsg += picMsg
            else:
                errNum = '701'
        else:
            # 连接出现问题，获取错误码信息
            errNum = urlRet['code']

        if not (errNum == '0' or errNum == '752') and 'read' in urlRet:
            logMsg += str(urlRet['read'])

    # 参数不在配置文件中
    else:
        errNum = '4'

    #写日志和发邮件的内容在这里组合
    if not parms == '-1' and parms['NAME'] and parms['LOGPath']:
        ret = common.log_mail(parms['NAME'], apiCode, errNum, logMsg, url, parms['LOGPath'], logName)

        if ret != 1:
            errNum = '7'

    return errNum

# if config_api.GLOBAL_debugType == 1:
#     getRecommendList('JSYD')