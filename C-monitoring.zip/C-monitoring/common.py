# -*- coding: utf-8 -*-

import urllib
import urllib.request
import urllib.parse
import urllib.error
import http.client
import json
import threading
import smtplib
import socket
from email.mime.text import MIMEText
from email.header import Header
import time
from email.mime.multipart import MIMEMultipart
import os
import sys
import datetime
import configparser
import random
from xpinyin import Pinyin

import config_api

# 错误提示，errNo指定错误信息
GLOBAL_errorMsg = {
    '-1': '配置文件不全',
    '0': '接口正常。',
    '1': '接口连接超时！',
    '2': '接口retCode值异常！',
    '3': '接口无法连接！',
    '4': '接口请求参数有误！',
    '5': '接口返回值错误！',
    '6': '写日志失败！',
    '7': '邮件发送失败!',
    '8': '返回值类型不正确',
    '9': '未知错误！',
    '700': 'apk无法下载',
    '701': '接口返回值个数不符',
    '702': '接口返回值Name不在列表中或code与传入code不符',
    '703': '接口返回值action不在列表中',
    '704': '接口返回值中code值长度小于6',
    '705': '接口返回值个数统计字段出错',
    '706': '接口返回推荐位的Name不在列表中',
    '7061': '推荐位上挂的栏目code不存在或栏目为空',
    '707': '接口返回推荐位recommendContent格式不正确或不存在',
    '708': '接口返回推荐位recommendTemplate/recommendPosition格式不正确或不存在',
    '709': '接口返回栏目树的level/categoryItem不存在或格式不符',
    '710': '接口返回栏目树的栏目数量不符合',
    '711': '接口返回栏目树的code或name错误',
    '712': '接口返回栏目树的一级栏目下产品包数量为空',
    '713': '接口返回栏目树的二级栏目下产品包数量为空',
    '714': '接口返回栏目树的一级栏目下不存在二级栏目',
    '715': '接口返回栏目树的level不为0,1,2',
    '716': '接口返回栏目树的一级栏目与它的子栏目产品包数量不符',
    '717': '接口返回栏目树的二级栏目parentCode出错',
    '718': '接口返回栏目树的栏目name/packageCodes/categoryCode为空',
    '719': '接口返回栏目树二级栏目的parentCode不存在',
    '720': '接口返回全局导航的navigationCode/navigationItem错误',
    '721': '接口返回全局导航的推荐位code或者name不在列表中',
    '722': '接口返回全局导航的code/name/action/recommendCode节点不存在或为空值',
    '723': '接口返回全局导航的navigationCode或navigationItem节点不存在',
    '730': '接口返回节目集详情为空',
    '731': '接口返回节目集详情的action/programName/programCode/movieList/movieUrl/programSequence为空或格式不符',
    '732': '接口返回节目集详情的seriesCode/seriesName/programList/pictureurl1/programCount为空/格式不符或集数期数出现负数',
    '733': '接口返回节目集详情的programCount小于0',
    '734': '接口返回节目集详情的programCount节点不存在',
    '735': '接口返回节目集详情的movieUrl不正确',
    '736': '接口返回节目集详情的总集数与实际集数不符',
    '737': '接口返回剧集编号为0',
    '740': '接口返回订单列表assetCode或assetName为空',
    '741': '接口返回产品价签列表pricingCode或pricingName为空',
    '742': '接口返回产品包价签列表packageCode或packageName为空',
    '750': '接口返回专题包的packagePictureUrl为空',
    '751': '接口返回产品包的action/Code/Name为空或action不在列表中',
    '752': '接口返回产品的pictureUrl为空',
    '753': '接口返回专题包中产品数量不足/产品包中没有产品。',
    '754': '接口返回专题包的pictureUrl1/pictureUrl2（海报图/背景图）为空',
    '755': '接口返回专题包的packageCode/packageName/specCornerImg/templateType/action/packageType1/type节点不存在或为空值',
    '760': '接口返回值中设定的节点不正确',
    '761': '接口返回值中serviceComboCode/agentCode不正确',
    '762': '接口返回值中serviceGroupCode/serviceComboCode不正确',
    '770': '接口返回搜索结果productCode/productName/action/pictureUrl节点不存在',
    '771': '接口返回搜索结果中action值异常',
    '772': '接口返回搜索结果中listInfo节点下为空',
    '780': '接口返回推荐位的remdList/totalRows/totalContents节点不存在',
    '781': '接口返回推荐位的navigationItemCode/navigationItemName/rowCount/remmendList节点不存在或不在列表中',
    '782': '接口返回推荐位的totalRows或totalContents值与实际计算值不符',
    '783': '接口返回推荐位的width/height/row/name/contentList节点不存在或推荐位存在空行',
    '784': '接口返回推荐位的idx/serviceType/assetCode/action节点不存在或code/name/posterUrl节点为空值',
    '785': '接口返回EPG5.0推荐位的行尺寸不符合要求',
    '786': '接口返回EPG5.0推荐位不同serviceType对应的关键节点不存在',
    '787': '接口返回推荐位的海报图片无法展示',
    '790': '接口返回壁纸的code/name/serviceCombo/reduceUrl/httpUrl节点为空值',
    '791': '接口返回壁纸的code/name/serviceCombo/reduceUrl/httpUrl节点不存在',
    '792': '接口返回壁纸的listInfo节点下为空值',
    '793': '接口返回壁纸的count/listInfo节点不存在',
    '794': '接口返回开机壁纸的status节点不存在或为空值',
    '800': '接口返回标签的typeCode值不正确',
    '801': '接口返回标签的attributeInfo节点下为空值',
    '802': '接口返回标签的typeCode/typeName节点不存在',
    '803': '接口返回标签的keyword/value/sequence节点为空值',
    '804': '接口返回标签的keyword/value/sequence节点不存在',
    '810': '接口返回关联搜索的code/name/serviceType/assetCode/posterType/posterUrl/action节点为空值',
    '811': '接口返回关联搜索的code/name/serviceType/assetCode/posterType/posterUrl/action节点不存在',
    '812': '接口返回关联搜索的showName/assetType/displayIndex节点不存在',
    '820': '接口返回空白推荐的count/pageLimit/listInfo节点为空值',
    '821': '接口返回空白推荐的count/pageLimit/listInfo节点不存在',
    '822': '接口返回空白推荐的listInfo节点类型不正确',
    '823': '接口返回空白推荐的action节点值不在列表中',
    '824': '接口返回空白推荐的isFee/pictureType/credits/programType2/corners节点不存在',
    '825': '接口返回空白推荐的productCode/productName/itemCode/pictureUrl/action/type/programType节点为空值',
    '826': '接口返回空白推荐的productCode/productName/itemCode/pictureUrl/action/type/programType节点不存在',
    '830': '接口返回热门搜索推荐的count/pageLimit/listInfo节点为空值',
    '831': '接口返回热门搜索推荐的count/pageLimit/listInfo节点不存在',
    '832': '接口返回热门搜索推荐的listInfo节点类型不正确',
    '833': '接口返回热门搜索推荐的action节点值不在列表中',
    '834': '接口返回热门搜索推荐的isFee/pictureType/credits/corners节点不存在',
    '835': '接口返回热门搜索推荐的productCode/productName/itemCode/pictureUrl/action/type节点为空值',
    '836': '接口返回热门搜索推荐的productCode/productName/itemCode/pictureUrl/action/type节点不存在',
    '840': '接口返回防盗链接口的密钥长度小于100',
    '841': '配置文件中的参数缺失或该业务组合不需要进行防盗链验证。',
    '850': '统一搜索接口无法搜到指定产品。',
    '851': '统一搜索接口返回值中缺少关键节点或关键节点为空值。',
    100: '接口返回HTTP状态码：100, Continue 初始的请求已经接受，客户应当继续发送请求的其余部分',
    101: '接口返回HTTP状态码：101, Switching Protocols 服务器将遵从客户的请求转换到另外一种协议',
    200: '接口返回HTTP状态码：200。但retMsg不存在或格式不正确',
    201: '接口返回HTTP状态码：201, Created 服务器已经创建了文档，Location头给出了它的URL',
    202: '接口返回HTTP状态码：202, Accepted 已经接受请求，但处理尚未完成。 ',
    203: '接口返回HTTP状态码：203, Non-Authoritative Information 文档已经正常地返回，但一些应答头可能不正确。',
    204: '接口返回HTTP状态码：204, No Content 没有新文档，浏览器应该继续显示原来的文档。',
    205: '接口返回HTTP状态码：205, Reset Content 没有新的内容，但浏览器应该重置它所显示的内容。',
    206: '接口返回HTTP状态码：206, Partial Content 客户发送了一个带有Range头的GET请求，服务器完成了它。 ',
    300: '接口返回HTTP状态码：300, Multiple Choices 客户请求的文档可以在多个位置找到。',
    301: '接口返回HTTP状态码：301, Moved Permanently 客户请求的文档在其他地方。 ',
    302: '接口返回HTTP状态码：302, Moved Temporatily 客户请求的文档临时存在在其他地方',
    303: '接口返回HTTP状态码：303, See Other',
    304: '接口返回HTTP状态码：304, Not Modified 客户端有缓冲的文档并发出了一个条件性的请求',
    305: '接口返回HTTP状态码：305,  Use Proxy 客户请求的文档应该通过Location头所指明的代理服务器提取',
    307: '接口返回HTTP状态码：307, Temporary Redirect',
    400: '接口返回HTTP状态码：400, Bad Request 请求出现语法错误。 ',
    401: '接口返回HTTP状态码：401, Unauthorized 客户试图未经授权访问受密码保护的页面。',
    403: '接口返回HTTP状态码：403, Forbidden 资源不可用。',
    404: '接口返回HTTP状态码：404, Not Found 无法找到指定位置的资源。',
    405: '接口返回HTTP状态码：405, Method Not Allowed 请求方法对指定的资源不适用。',
    406: '接口返回HTTP状态码：406, Not Acceptable 指定的资源已经找到，但它的MIME类型和客户在Accpet头中所指定的不兼容。',
    407: '接口返回HTTP状态码：407, Proxy Authentication Required',
    408: '接口返回HTTP状态码：408, Request Timeout',
    409: '接口返回HTTP状态码：409, Conflict 通常和PUT请求有关。由于请求和资源的当前状态相冲突，因此请求不能成功。',
    410: '接口返回HTTP状态码：410, Gone 所请求的文档已经不再可用，而且服务器不知道应该重定向到哪一个地址。',
    411: '接口返回HTTP状态码：411, Length Required 服务器不能处理请求，除非客户发送一个Content-Length头。',
    412: '接口返回HTTP状态码：412, Precondition Failed 请求头中指定的一些前提条件失败',
    413: '接口返回HTTP状态码：413, Request Entity Too Large 目标文档的大小超过服务器当前愿意处理的大小。',
    414: '接口返回HTTP状态码：414, Request URI Too Long URI太长',
    416: '接口返回HTTP状态码：416, Requested Range Not Satisfiable 服务器不能满足客户在请求中指定的Range头。',
    417: '接口返回HTTP状态码：417, （未满足期望值） 服务器未满足”期望”请求标头字段的要求。',
    500: '接口返回HTTP状态码：500, Internal Server Error 服务器遇到了意料不到的情况，不能完成客户的请求。 ',
    501: '接口返回HTTP状态码：501, Not Implemented 服务器不支持实现请求所需要的功能',
    502: '接口返回HTTP状态码：502, Bad Gateway ',
    503: '接口返回HTTP状态码：503, Service Unavailable 服务器由于维护或者负载过重未能应答。',
    504: '接口返回HTTP状态码：504, Gateway Timeout 由作为代理或网关的服务器使用，表示不能及时地从远程服务器获得应答。',
    505: '接口返回HTTP状态码：505, HTTP Version Not Supported 服务器不支持请求中所指明的HTTP版本。'
}

GLOBAL_apiName = {
    '[101]': '终端认证(deviceAuth)',
    '[102]': '终端初始化(deviceInit)',
    '[103]': '获取全局导航(getNavigationInfo)',
    '[104]': '获取栏目树(getCategoryList)',
    '[105]': '获取专题包(getPackageInfoByCode)',
    '[106]': '获取列表页产品(getProductList)',
    '[107]': '获取节目集详情(getSeriesInfoByCode)',
    '[108]': '获取推荐位(getRecommendInfo)',
    '[109]': '关联推荐(getRecommendList)',
    '[110]': '获取产品价签信息(getProductPricing)',
    '[111]': '判断APK是否存在:',
    '[112]': '搜索&筛选(getCommodityListBySerach):',
    '[113]': '获取EPG5.0推荐位(getRecommendInfo5)',
    '[114]': '获取EPG5.0壁纸（getWallPaper）',
    '[115]': '获取EPG5.0筛选标签(getTagList)',
    '[116]': '获取EPG5.0关联搜索（recommend/box）',
    '[117]': '获取EPG5.0空白推荐（blankBySerach）',
    '[118]': '获取EPG5.0热门搜索（searchTop）',
    '[120]': '收藏商品|取消收藏商品(setFavouriteInfoByUser)',
    '[121]': '收藏记录查询(getFavouriteInfoByUser)',
    '[122]': '删除用户所有收藏商品(setDelFavouriteInfoByUser)',
    '[123]': '查询用户是否收藏某一节目集(getProductIsFavourite)',
    '[124]': '记录播放历史信息（setPlayHistoryInfoByUser）',
    '[125]': '播放历史查询(getPlayHistoryInfoByUser)',
    '[126]': '删除播放历史信息(deletePlayHistoryInfo)',
    '[127]': '防盗链（seriesInfo!getAuthInfo）',
    '[128]': '统一搜索(江苏移动usech)',
    '[129]': '专题汇总（getPackageList）'
}

# get方式连接接口，并获取接口的返回值
def getUrlRet(url, logName, retName = config_api.GLOBAL_retName, retCode = config_api.GLOBAL_retCode, type=1):
    num = 0
    ret = {}
    ret['code'] = '9'
    logMsg = ''
    headers = {'User-Agent': 'User-Agent:Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/56.0.2924.87 Safari/537.36'}
    # 设置超时
    socket.setdefaulttimeout(config_api.GLOBAL_setTimeOut)

    # 如果连接不上，重试一次，减少误报
    while num < 2:
        try:
            if type == 1:   # json 格式
                url_getInfo = urllib.request.Request(url, headers=headers)
                url_getInfo_read = urllib.request.urlopen(url_getInfo).read()
                url_getInfo_read = url_getInfo_read.decode("utf-8")
                ret['read'] = json.loads(url_getInfo_read)
            elif type == 2:
                url_getInfo_read = urllib.request.urlopen(url).read()
                ret['read'] = url_getInfo_read.decode("utf-8")
            elif type == 4:     # 只判断返回code为200 即可
                response = urllib.request.urlopen(url)
            else:
                ret['code'] = '4'
        # try 和 except只能捕获他们之间的语句产生的异常，此处是捕获的请求的异常，主要是超时
        except Exception as e:
            num += 1
            time.sleep(3)
            if hasattr(e, 'code'):
                ret['code'] = e.getcode()
                ret['read'] = e.read()
                # print(config_api.GLOBAL_setTimeOut)
            elif hasattr(e, 'reason'):
                ret['code'] = '1'
                ret['read'] = e.reason
            else:
                ret['code'] = '3'
                ret['read'] = str(e) + '\n'
        else:
            ret['code'] = 200
            if type != 4 and not ret['read'][retName] == retCode:   # type=4 只判断返回code为200 即可
                logMsg = retName + ':' + ret['read'][retName] + '\n'
                ret['code'] = '2'
            if type == 3:
                logMsg += url + '\n'
            writeLog(logName, logMsg, 0)
            break
    return ret

# 获取url返回值，判断返回值是否正确
def get_url(parms, url, apiCode, logName, check_type = 1, retCode = '', check_key = '', check_value = '', listName = 'listInfo'):
    errNum = '9'
    logMsg = ''
    retName = config_api.GLOBAL_retName
    if retCode == '':
        retCode = config_api.GLOBAL_retCode
    # 请求接口
    urlRet = getUrlRet(url, parms['LOGPath'] + logName, retName, retCode)

    # 判断返回值code为200，则检查返回值内容是否正确
    if urlRet['code'] == 200:
        res = check_ret(urlRet['read'], check_type, check_key, check_value, '', listName)
        if check_type == 5:
            return res['msg']
        else:
            errNum = res['code']
            logMsg = res['msg']
    else:
        # 连接出现问题，获取错误码信息
        errNum = urlRet['code']

        if 'read' in urlRet:
            logMsg += str(urlRet['read']) + '\n'

    #写日志和发邮件的内容在这里组合
    ret = log_mail(parms['NAME'], apiCode, errNum, logMsg, url, parms['LOGPath'], logName)
    if ret != 1:
        errNum = '7'

    return errNum

# 按类型判断data中key是否等于value
def check_ret(data, type, key = '', value = '', path = '', listName = 'listInfo'):
    ret = {}
    ret['code'] = '9'
    ret['msg'] = ''
    if path == '':
        path = 'retMsg'
    if path in data:
        ret_value = get_json_value(data[path], key, type)
        if type == 1:
            ret['code'] = '0'
        elif type == 2 and listName in data[path] and key in data[path][listName][0] and data[path][listName][0][key] == value:
            ret['code'] = '0'
        elif type == 3 and key in data[path] and data[path][key] == value:
            ret['code'] = '0'
        elif type == 4 and key in data and data[key] == value:
            ret['code'] = '0'
        elif type == 5 and listName in data[path] and key in data[path][listName][0]:
            ret['code'] = '0'
            ret['msg'] = data[path][listName][0][key]
        else:
            ret['code'] = '760'
            ret['msg'] = '判断条件：%s=%s; 实际返回值：%s \n' % (key, value, ret_value)
    else:
        ret['code'] = '8'
        ret['msg'] = data
    return ret

# 发送POST请求
def getUrlPost(url, data=None, headers=None, timeout=2, decode='utf-8'):
    if headers is None:
        headers = {}

    post_data = urllib.parse.urlencode(data).encode(decode)

    try:
        req = urllib.request.Request(url, post_data, headers)
        hr = urllib.request.urlopen(req, timeout=timeout)
        rt = hr.read().decode(decode)
    finally:
        return rt

# 判断data中是否存在checkName节点,且长度是否等于(type=1)或大于(type=2)checkLen，返回True或Flase
def check_Len(data, checkName='', checkLen=1, type=1):
    if type == 1 and checkName in data and len(data[checkName]) == checkLen:
        return True
    elif type == 2 and checkName in data and len(data[checkName]) > checkLen:
        return True
    elif type == 3 and checkName in data and data[checkName] > checkLen:
        return True
    else:
        return False

# 返回True或Flase
# type=1时，判断list中的key都在data中，且value相等
# type=2时，判断list中的key都在data中
# type=3时，判断list中的key都在data中，且data[key]值(int)大于str_len或data[key]长度（非int）大于str_len
def check_list(data, list, check_type=1, str_len=0):
    count = 0
    for key in list:
        if check_type == 1 and key in data and data[key] == list[key]:
            count += 1
        elif check_type == 2 and key in data:
            count += 1
        elif check_type == 3 and key in data:
            if type(data[key]) in {int, float} and data[key] > str_len:
                count += 1
            elif (not type(data[key]) in {bool, int, float}) and len(data[key]) > str_len:
                count += 1
    if count == len(list):
        return True
    return False

# 返回data中所有key的值
def get_json_value(data, key, type=1):
    data = str(data)
    sp = key+'\':'
    slist = data.split(sp)
    n = 1
    ret = key + ''
    while n < len(slist):
        value = slist[n].split(',')
        ret += value[0]
        n += 1
    if type == 4:
        ret = data
    ret += '\n'
    return ret

# 写日志
def writeLog(path,msg,isTime = 1):
    try:
        with open(path, 'a', encoding='utf-8') as file_object:
        # 写入日志
            file_object.write(msg)
            if isTime == 1:
                time_num = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
                file_object.write('================the Operation time is %s====================' % time_num + '\n\n')
    except Exception as e:
        ret_msg = '1'
    else:
        ret_msg = '0'
    return ret_msg

# 发送邮件,errorMsg：邮件内容，path：log日志的存放路径，logName：日志文件名，是必填参数，sender、password，receivers，mailSubject发送、密码，接收，标题非必填，默认从config_api获取
def sendmail(errorMsg, path, logName, logCode, sender=config_api.GLOBAL_sender, password=config_api.GLOBAL_password, receivers=config_api.GLOBAL_receivers, mailSubject=config_api.GLOBAL_mailSubject):
    errMail = ['未知错误','邮件已发送','邮件无法发送','邮件发送参数错误']
    errNo = 0
    if len(errorMsg) > 3 and len(path) > 3 and len(logName) > 3:
        # 创建一个带附件的实例，这是必须的!!!!!!!!
        message = MIMEMultipart()
        message.attach(MIMEText(errorMsg, 'plain', 'utf-8'))
        message['From'] = sender
        message['To'] = ';'.join(receivers)
        message['Subject'] = Header(mailSubject, 'utf-8')

        # 构造附件1，传送指定目录下的文件
        att1 = MIMEText(open(path, 'rb').read(), 'base64', 'utf-8')
        att1["Content-Type"] = 'application/octet-stream'  #任意的二进制数据
        # 这里的filename可以任意写，写什么名字，邮件中显示什么名字
        att1["Content-Disposition"] = 'attachment; filename='+ logName
        message.attach(att1)

        try:
            smtpObj = smtplib.SMTP('smtp.guttv.cn',25)
            smtpObj.login(sender,password)
            smtpObj.sendmail(sender, receivers, message.as_string())
        except smtplib.SMTPException as e:
            errNo = 2
            print(e)
        else:
            errNo = 1
    else:
        errNo = 3
    logMsg = logCode + '; [mail]:' + str(errNo) + '; ' + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()) + '\n'
    writeLog(config_api.GLOBAL_mailLog, logMsg, 2)
    return errNo

def log_mail(name, apiCode, errNum, logMsg, url, logPath, logName, project_dingding_token = ''):
    errNo = 1
    logMsg = name + GLOBAL_apiName[apiCode] + GLOBAL_errorMsg[errNum] + '\n ' + logMsg
    if not errNum == '0':
        logMsg = '[error]' + logMsg + '\n'
    else:
        logMsg = '\n' + logMsg
    errMsg = logMsg + url + '\n'
    if config_api.GLOBAL_debugType == 1:
        print(errMsg)

    # 写log
    write_log = writeLog(logPath + logName, errMsg)
    if write_log == '1' and errNum == '0':
        errNum = '6'
        errMsg = errMsg + GLOBAL_errorMsg[errNum] + '\n'

    # 有错误，发送告警消息,发送成功返回1
    if not errNum == '0' and not config_api.GLOBAL_debugType == 1 and not errNum == '716':      # 排除虚包干扰
        logCode = config_api.GLOBAL_logCode[name] + apiCode + '[' + str(errNum) + '][' + url + ']'
        # 遍历栏目树的时候不发微信和邮件
        if not config_api.GLOBAL_debugType in {3, 4}:
            # 20170417 新增加发送微信的功能，测试中
            errNo = sendWeiXin(errMsg + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
            #errNo = sendmail(errMsg, logPath + logName, logName, logCode)
            # 20180326 新增。如果设置了发送钉钉，则发消息给指定的token
            if len(config_api.GLOBAL_DingDing_token) > 10:
                DingDing = sendDingDingMessage(errMsg + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
            # 需要推送给钉钉的项目群的消息
            if (int(errNum) > 700 or errNum == '2') and len(str(project_dingding_token)) > 10:
                sendDingDingMessage(errMsg + time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()), project_dingding_token)

    return errNo


"""
@update: 2017-1-6 15:42:59
@help: 获取并替换
        corpid 企业号ID
        corpsecret ID号密钥
        agentid app号
@run: python $0  'msg'
"""
def apilib(count=0, timeout=10, **argt):
    try:
        ret = urllib.request.urlopen(timeout=timeout, **argt).read().decode('utf-8')
        return json.loads(ret)
    except urllib.error.URLError as err:
        print(err.reason)
        print(err)
        if count < 3:
            count += 1
            if err.reason == 'timed out':
                time.sleep(timeout)
                apilib(count, timeout, **argt)
        else:
            return None


class WeiXinApi:
    """
    @params:
        corpid 企业号ID
        corpsecret ID号密钥
        agentid app号
    """

    def __init__(self, corpid, corpsecret):
        self.corpsecret = corpsecret
        self.corpid = corpid
        self.access_token = None
        self.host = 'https://qyapi.weixin.qq.com'

    # 获取AccessToken
    def get_AccessToken(self):
        url_path = '/cgi-bin/gettoken'
        data = {"corpsecret": self.corpsecret,
                "corpid": self.corpid,
                }
        url = urllib.parse.urljoin(self.host, url_path) + '?' + urllib.parse.urlencode(data)
        res = apilib(url=url)

        if res and "access_token" in res.keys():
            self.access_token = res["access_token"]
            return res["expires_in"]
        if res and "errmsg" in res.keys(): print(res["errmsg"])
        return None

    # 发送接口
    def sendmsg(self, msg, agentid):

        if not self.access_token:
            self.get_AccessToken()
        url_path = '/cgi-bin/message/send?access_token=%s&lang=zh_CN' % self.access_token
        data = {
            "touser": "@all",
            "toparty": None,
            "totag": None,
            "msgtype": "text",
            "agentid": agentid,
            "text": {
                "content": msg
            },
            "safe": "0"
        }

        # 使用该方法，可以实现微信发送中文
        data = json.dumps(data, ensure_ascii=False).encode('utf8')
        url = urllib.parse.urljoin(self.host, url_path)

        # apilib(url=url,data=data)里的data就不用再encode了
        res = apilib(url=url, data=data)
        logMsg = format(res)
        if res and "errcode" in res.keys() and res["errcode"] == 0:
            ret = 0
        else:
            ret = 1
        writeLog(config_api.GLOBAL_weixin_log, logMsg)
        return ret

def sendWeiXin(err_msg):
    send_ret = ''
    # 如果没有对应的文件夹，会自动创建
    if not os.path.exists(os.path.dirname(config_api.GLOBAL_weixin_log)):
        os.mkdir(os.path.dirname(config_api.GLOBAL_weixin_log))
    # 推送微信
    try:
        send = WeiXinApi(config_api.GLOBAL_CorpID, config_api.GLOBAL_Secret)
        send_ret = send.sendmsg(msg=err_msg, agentid=config_api.GLOBAL_agentid)
    except Exception as err:
        send_ret = '-1'

    return send_ret

# 发送钉钉消息
def sendDingDingMessage(content, access_token = config_api.GLOBAL_DingDing_token):
    send_ret = '0'
    data = {
        "msgtype": "text",
        "text": {
            "content": content
        }
    }
    url = "/robot/send?access_token=%s" % access_token
    headers = {"Content-Type": "application/json; charset=utf-8"}
    host = 'oapi.dingtalk.com'
    # 如果没有对应的文件夹，会自动创建
    if not os.path.exists(os.path.dirname(config_api.GLOBAL_weixin_log)):
        os.mkdir(os.path.dirname(config_api.GLOBAL_weixin_log))
    data = json.dumps(data)
    # 发送消息
    try:
        conn = http.client.HTTPSConnection(host)
        conn.request('POST', url, data, headers)
        response = conn.getresponse()
        data = json.loads(response.read().decode('utf-8'))
        conn.close()
    except Exception as err:
        send_ret = '-1'
    # 判断返回值是否正确
    if 'errcode' in data and not data['errcode'] == 0:
        send_ret = '-2'
    elif send_ret == '0':
        send_ret = '-3'

    return send_ret

# 判断列表parms里的值都不为False，返回True
def check_parms(parms):
    ret = True
    for parm in parms:
        if parms[parm]:
            continue
        else:
            ret = False
            break
    return ret

class Config:
    def __init__(self, conf_sec, conf_file=config_api.GLOBAL_rootLogPath + 'conf.ini'):
        self.conf_sec = conf_sec
        self.conf_file = conf_file
        self.cf = configparser.ConfigParser()
        self.cf.read(self.conf_file)
        self.secs = self.cf.sections()
        if self.conf_sec in self.secs:
            self.opts = self.cf.options(self.conf_sec)
        else:
            self.opts = False

    def get_str(self, conf_key):
        if type(self.opts) == list and conf_key in self.opts:
            ret = self.cf.get(self.conf_sec, conf_key)
        else:
            ret = False
        return ret

    def get_int(self, conf_key):
        if type(self.opts) == list and conf_key in self.opts:
            ret = self.cf.getint(self.conf_sec, conf_key)
        else:
            ret = False
        return ret

    def get_list(self, conf_key):
        str = self.get_str(conf_key)
        if str:
            ret = str.split(',')
        else:
            ret = False
        return ret

def getConfig(apiCode, logName, control_name = '', conf_file=config_api.GLOBAL_rootLogPath + 'conf.ini'):
    parms = {}
    errNum = '0'
    if control_name == '':
        control_name = 'TEST'
    parms['LOGPath'] = config_api.GLOBAL_rootLogPath + control_name + '_log/'
    parms['SleepTime'] = config_api.GLOBAL_sleepTime
    parms['PageLimit'] = config_api.GLOBAL_pageLimit

    config = Config(control_name, conf_file)

    # 不能为空的参数
    parms['NAME'] = config.get_str('name')
    parms['OMS'] = config.get_str('oms')
    parms['VOD'] = config.get_str('vod')
    parms['MAC'] = config.get_str('mac')
    parms['ServiceComboCode'] = config.get_str('servicecombocode')
    parms['ServiceGroupCode'] = config.get_str('servicegroupcode')
    parms['AgentCode'] = config.get_str('agentcode')
    parms['UserCode'] = config.get_str('usercode')
    parms['CategoryName'] = config.get_str('categoryname')
    parms['CategoryCode'] = config.get_str('categorycode')
    parms['InitType'] = config.get_str('inittype')
    # 判断配置文件中的必填参数是否都存在
    if check_parms(parms) == False:
        errNum = '-1'
        ret = errNum
        logMsg = ''
        url = ''
        if parms['NAME']:
            log_mail(parms['NAME'], apiCode, errNum, logMsg, url, parms['LOGPath'], logName)
    else:
        # 允许为空的参数
        parms['BMS'] = config.get_str('bms')
        parms['UMS'] = config.get_str('ums')
        parms['APK'] = config.get_str('apk')
        parms['NavigationCode'] = config.get_str('navigationcode')
        parms['NavigationItemCode'] = config.get_list('navigationitemcode')
        parms['NavigationName'] = config.get_list('navigationname')
        parms['APK_URL'] = config.get_str('apk_url')
        parms['APK_PORT'] = config.get_str('apk_port')
        parms['PackageCode'] = config.get_str('packagecode')
        parms['ProductCode'] = config.get_str('productcode')
        parms['AuthCode'] = config.get_str('authcode')
        parms['AuthType'] = config.get_str('authtype')
        parms['Token'] = config.get_str('token')
        parms['DomainCodes'] = config.get_str('domaincodes')
        parms['RecommendCode'] = config.get_list('recommendcode')
        parms['RecommendName'] = config.get_str('recommendname')
        parms['Recommend_0'] = config.get_list('recommend_0')
        parms['Recommend_1'] = config.get_list('recommend_1')
        parms['Recommend_3'] = config.get_list('recommend_3')
        parms['Recommend_4'] = config.get_list('recommend_4')
        parms['Category_zt'] = config.get_str('category_zt')
        parms['miss_set'] = config.get_str('miss_set')
        if parms['Category_zt'] == False:
            parms['Category_zt'] = '全部专题'
        parms['ExternalUserCode'] = config.get_str('externalusercode')
        parms['IsBMS'] = config.get_str('isbms')
        parms['EPG'] = config.get_str('epg')
        parms['dingding_token'] = config.get_str('dingding_token')
        ret = parms
    return ret

# 循环获取文件中每行的内容，写入list
def get_text_to_list(fileName):
    # print(fileName)
    ret = []
    f = open(fileName, "r+")  # 返回一个文件对象
    line = f.readline()  # 调用文件的 readline()方法
    while line:
        ret.append(line.strip())
        line = f.readline()
    f.close()
    # print(ret)
    return ret

def getRandom():
    ret = '&%s=%s' %(config_api.GLOBAL_Random_name, random.randrange(1000000, 9999999))
    return ret

# type=1, 返回data的拼音首字母,如果有特殊符号，则返回特殊符号之前的内容
def getPinyin(data, type=1):
    p = Pinyin()
    ret = '9'
    if type == 1:
        pinyin = p.get_initials(data, u'')
        ret = pinyin.split()[0]
    return ret