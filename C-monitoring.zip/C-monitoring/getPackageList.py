#!/usr/bin/env python
# -*- coding: utf-8 -*-

import time
import config_api
import common
from getProductList import getProductList

def getPackageList(control_name, packageCodes = '', aliasName = '', url1 = ''):
    errNum = '9'
    picMsg = ''
    logMsg = ''
    url = ''
    count = 0
    apiCode = '[129]'  # 专题汇总（getPackageList）
    ptype = '专题汇总'
    logName = control_name + '_getPackageList_log.txt'
    listInfo = 'listInfo'
    action = 'action'
    packageCount = 'count'
    packageName = 'packageName'
    package_code = 'packageCode'
    # 节点存在即可
    check_list = {'specCornerImg'}
    # 非空节点
    un_empty_list = {'packageCode', 'packageName', 'action', 'packageType1', 'type'}
    # 对长度有要求的节点
    check_len_list = {'pictureUrl1', 'pictureUrl2'}
    # 必须达到或超过的长度
    check_len = 9
    zt_action = 'OPEN_SPECIAL_TEMPLATE_1'
    procuct_count = config_api.GLOBAL_ZTNum

    # 判断参数是否正确,如果在列表里，则可以开始拼装参数，发送url请求
    parms = common.getConfig(apiCode, logName, control_name)

    if not parms == '-1':
        # 拼装url
        if packageCodes == '':
            packageCodes = parms['PackageCode']
        url = 'http://%s/vod_api/assetList!getPackageList?serviceGroupCode=' % parms['VOD']
        url += '%s&packageCodes=%s' % (parms['ServiceGroupCode'], packageCodes)

        # 请求接口加随机数
        url += common.getRandom()  # 获取随机参数
        urlRet = common.getUrlRet(url, parms['LOGPath'] + logName)

        # 判断返回值code为200，则检查返回值内容是否正确
        if urlRet['code'] == 200 and 'read' in urlRet:
            if not aliasName == '':
                logMsg += ptype + ': ' + aliasName + '； '
            # 判断返回值是否正确
            data = urlRet['read']['retMsg']
            if type(data) == dict and packageCount in data and listInfo in data and type(data[listInfo]) == list and data[packageCount] > 0 and len(data[listInfo]) > 0:
                # count:n; packageCode:xxxxxxxx
                logMsg += '%s: %s； %s: %s；\n' % (packageCount, str(data[packageCount]), package_code, packageCodes)
                logMsg += '抽查结果：'
                for info in data[listInfo]:
                    count += 1
                    if count > config_api.GLOBAL_checkListNum:
                        break
                    if packageName in info:
                        logMsg += '专题包： %s。\n' % info[packageName]
                    if common.check_list(info, check_list, 2) and common.check_list(info, un_empty_list, 3) and info[action] == zt_action:
                        logMsg += '%s: %s；%s: %s \n' % (package_code, info[package_code], action, info[action])
                        # 判断图片pictureUrl如果不存在，则记录告警, EPG5.0除外
                        if not (common.check_list(info, check_len_list, 3, check_len) or parms['EPG'] == '5.0'):
                            errNum = '754'
                            break
                        else:
                            errNum = '0'
                            # 调取获取专题包接口
                            getProductList(control_name, info[package_code], info[packageName], 1, url, procuct_count)
                    # 缺少字段或不能为空的字段出现空值
                    elif info[action] == zt_action:
                        errNum = '755'
                        break
            elif packageCodes == '2100130022233552311200191':
                errNum = '0'
                logMsg += '安徽移动推广特殊需求，挂空包。\n'
            else:
                errNum = '701'
                logMsg += 'count为0或listInfo为空或格式不符。\n'
        else:
            # 连接出现问题，获取错误码信息
            errNum = urlRet['code']
            if 'read' in urlRet:
                logMsg += str(urlRet['read'])
        if not url1 == '':
            logMsg += '清上级入口缓存：' + url1 + config_api.GLOBAL_delete_redis + '\n'

        #写日志和发邮件的内容在这里组合
        if parms['NAME'] and parms['LOGPath']:
            ret = common.log_mail(parms['NAME'], apiCode, errNum, logMsg, url, parms['LOGPath'], logName, parms['dingding_token'])
            if ret != 1:
                errNum = '7'

    return errNum

#if config_api.GLOBAL_debugType == 1:
#    getProductList('SDYD')