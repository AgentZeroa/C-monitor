#!/usr/bin/env python
# -*- coding: utf-8 -*-

import time
import config_api
import common
from getSeriesInfoByCode import getSeriesInfoByCode

# 判断获取EPG5.0壁纸(wallpaper!getData)接口返回的retCode是否正确
def getWallPaper(control_name):
    errNum = '9'
    url = ''
    logName = control_name + '_getWallPaper_log.txt'
    apiCode = '[114]'
    logMsg = ''
    # 判断关键节点是否存在
    n_list = {'count', 'listInfo'}           # retMsg下必须存在的节点，且不能为空值
    c_list = {'code', 'name', 'serviceCombo', 'reduceUrl', 'httpUrl'}    # retMsg['listInfo']下必须存在的节点，且不能为空值

    # 判断参数是否正确,如果在列表里，则可以开始拼装参数，发送url请求
    parms = common.getConfig(apiCode, logName, control_name)

    if not parms == '-1':
        errNum = '9'
        w_type = 1
        t_type = 2
        while w_type <= t_type :
            # 拼装url
            url = 'http://%s/oms_api/wallpaper!getData?comboCode=%s&type=%s' % (parms['OMS'], parms['ServiceComboCode'], w_type)
            url += common.getRandom()  # 获取随机参数

            # 请求接口
            urlRet = common.getUrlRet(url, parms['LOGPath'] + logName)

            # 判断返回值code为200，则检查返回值内容是否正确
            if urlRet['code'] == 200 and 'retMsg' in urlRet['read'] and type(urlRet['read']['retMsg']) == dict:
                data = urlRet['read']['retMsg']
                # 判断返回值是否正确
                if common.check_list(data, n_list, 3) and type(data['listInfo']) == list:
                    logMsg = '获取壁纸数量为：%s \n' % data['count']
                    checkNum = 0
                    for info in data['listInfo']:
                        if common.check_list(info, c_list, 3):
                            if (w_type == 1 and common.check_list(info, {'status'}, 3)) or w_type != 1:
                                logMsg += 'code: ' + info['code'] + '；name: ' + info['name'] + '\n '
                                errNum = '0'
                            else:
                                errNum = '794'
                        elif common.check_list(info, c_list, 2):
                            errNum = '790'
                            logMsg += 'name：' + info['name'] + '；code：' + info['code'] + '\n'
                            break
                        else:
                            errNum = '791'
                            logMsg += str(info) + '\n'
                            break
                        # 检查条目数
                        checkNum += 1
                        if checkNum >= config_api.GLOBAL_checkListNum:
                            break
                elif common.check_list(data, n_list, 2):
                    errNum = '792'
                else:
                    errNum = '793'
            else:
                # 连接出现问题，获取错误码信息
                errNum = urlRet['code']

                if 'read' in urlRet:
                    logMsg += str(urlRet['read'])
            w_type += 1
            # 写日志和发邮件的内容在这里组合
            if not parms == '-1' and parms['NAME'] and parms['LOGPath']:
                ret = common.log_mail(parms['NAME'], apiCode, errNum, logMsg, url, parms['LOGPath'], logName)
                if ret != 1:
                    errNum = '7'

    else:
        errNum = '-1'

    return errNum

# 获取筛选标签接口
def getTagList(control_name):
    errNum = '9'
    url = ''
    logName = control_name + '_getTagList_log.txt'
    apiCode = '[115]'
    logMsg = ''
    # 判断关键节点是否存在
    n_list = {'typeCode', 'typeName', 'attributeInfo'}  # retMsg下必须存在的节点，且不能为空值
    c_list = {'keyword', 'value', 'sequence'}  # retMsg['attributeInfo']下必须存在的节点，且不能为空值

    # 判断参数是否正确,如果在列表里，则可以开始拼装参数，发送url请求
    parms = common.getConfig(apiCode, logName, control_name)

    if not parms == '-1':
        errNum = '9'
        # 拼装url
        for typeC in config_api.GLOBAL_tagList:
            url = 'http://%s/vod_api/tagInfo!getTagList?typeCode=%s' % (parms['VOD'], typeC)
            url += common.getRandom()  # 获取随机参数

            # 请求接口
            urlRet = common.getUrlRet(url, parms['LOGPath'] + logName)
            # 判断返回值code为200，则检查返回值内容是否正确
            if urlRet['code'] == 200 and 'retMsg' in urlRet['read'] and type(urlRet['read']['retMsg']) == list:
                type_count = len(urlRet['read']['retMsg'])
                num = 0
                for data in urlRet['read']['retMsg']:
                    # 判断返回值是否正确
                    if common.check_list(data, n_list, 3) and type(data['attributeInfo']) == list and data['typeCode'] == typeC:
                        logMsg = '获取标签：%s \n' % typeC
                        checkNum = 0
                        for info in data['attributeInfo']:
                            if common.check_list(info, c_list, 3):
                                logMsg += 'keyword: ' + info['keyword'] + '；value: ' + info['value'] + '\n '
                                errNum = '0'
                            elif common.check_list(info, c_list, 2):
                                errNum = '803'
                                logMsg += 'keyword：' + info['keyword'] + '；value：' + info['value'] + '\n'
                                break
                            else:
                                errNum = '804'
                                logMsg += str(info) + '\n'
                                break
                            # 检查条目数
                            checkNum += 1
                            if checkNum >= config_api.GLOBAL_checkListNum:
                                break
                    elif common.check_list(data, n_list, 3) and type(data['attributeInfo']) == list:
                        num += 1
                    elif common.check_list(data, n_list, 2):
                        errNum = '801'
                    else:
                        errNum = '802'
                # 如果返回结果中未出现搜索的关键词，则报错
                if num == type_count:
                    errNum = '800'
                    logMsg = '未获得预期的标签名：%s；' % typeC
            else:
                # 连接出现问题，获取错误码信息
                errNum = urlRet['code']

                if 'read' in urlRet:
                    logMsg += str(urlRet['read'])
            # 写日志和发邮件的内容在这里组合
            if not parms == '-1' and parms['NAME'] and parms['LOGPath']:
                ret = common.log_mail(parms['NAME'], apiCode, errNum, logMsg, url, parms['LOGPath'], logName)
                if ret != 1:
                    errNum = '7'
            time.sleep(parms['SleepTime'])
    else:
        errNum = '-1'

    return errNum

# 获取关联搜索接口
def recommend_box(control_name):
    errNum = '9'
    url = ''
    logName = control_name + '_recommend_box_log.txt'
    apiCode = '[116]'
    # 判断关键节点是否存在, retMsg下必须存在的节点，且不能为空值
    un_empty = {'code', 'name', 'serviceType', 'assetCode', 'posterType', 'posterUrl', 'action'}
    # retMsg下必须存在的节点，允许为空值
    con_list = {'showName', 'assetType', 'displayIndex'}

    # 判断参数是否正确,如果在列表里，则可以开始拼装参数，发送url请求
    parms = common.getConfig(apiCode, logName, control_name)

    if not parms == '-1':
        errNum = '9'
        # 拼装url
        for boxType in config_api.GLOBAL_boxList:
            url = 'http://%s/oms_api/recommend/box?comboCode=%s&boxType=%s' % (parms['OMS'], parms['ServiceComboCode'], boxType)
            url += common.getRandom()  # 获取随机参数
            logMsg = ''
            # 请求接口
            urlRet = common.getUrlRet(url, parms['LOGPath'] + logName)
            # 判断返回值code为200，则检查返回值内容是否正确
            if urlRet['code'] == 200 and 'retMsg' in urlRet['read'] and type(urlRet['read']['retMsg']) == list:
                checkNum = 0
                for data in urlRet['read']['retMsg']:
                    # 判断返回值是否正确
                    if common.check_list(data, un_empty, 3) and common.check_list(data, con_list, 2):
                        errNum = '0'
                        logMsg += 'boxType:%s, code:%s, name：%s \n' % (boxType, data['code'], data['name'])
                    elif common.check_list(data, un_empty, 3):
                        errNum = '812'
                        logMsg += 'boxType:%s, code:%s, name：%s \n' % (boxType, data['code'], data['name'])
                    elif common.check_list(data, un_empty, 2):
                        errNum = '810'
                        logMsg = 'boxType:%s, name：%s \n' % (boxType, data['name'])
                        break
                    else:
                        errNum = '811'
                        break
                    # 检查条目数
                    checkNum += 1
                    if checkNum >= config_api.GLOBAL_checkListNum:
                        break
            else:
                # 连接出现问题，获取错误码信息
                errNum = urlRet['code']

                if 'read' in urlRet:
                    logMsg += str(urlRet['read'])
            # 写日志和发邮件的内容在这里组合
            if not parms == '-1' and parms['NAME'] and parms['LOGPath']:
                ret = common.log_mail(parms['NAME'], apiCode, errNum, logMsg, url, parms['LOGPath'], logName)
                if ret != 1:
                    errNum = '7'
            time.sleep(parms['SleepTime'])
    else:
        errNum = '-1'

    return errNum

# 获取空白推荐接口
def blankBySerach(control_name):
    errNum = '9'
    url = ''
    logName = control_name + '_blankBySerach_log.txt'
    apiCode = '[117]'
    # 判断关键节点是否存在
    # retMsg下必须存在的节点，且不能为空值
    n_list = {'count', 'pageLimit', 'listInfo'}
    # listInfo下必须存在的节点，且不能为空值
    info_list = {'productCode', 'productName', 'itemCode', 'pictureUrl', 'action', 'type', 'programType'}
    # listInfo下必须存在的节点，允许为空值
    con_list = {'isFee', 'pictureType', 'credits', 'programType2', 'corners'}

    # 判断参数是否正确,如果在列表里，则可以开始拼装参数，发送url请求
    parms = common.getConfig(apiCode, logName, control_name)

    if not parms == '-1':
        errNum = '9'
        # 拼装url
        for blankType in config_api.GLOBAL_blankList:
            url = 'http://%s/vod_api/commodityList!blankBySerach?userCode=%s&serviceGroupCode=%s&blankType=%s' % (
            parms['VOD'], parms['UserCode'], parms['ServiceGroupCode'], blankType)
            url += common.getRandom()  # 获取随机参数

            logMsg = ''
            # 请求接口
            urlRet = common.getUrlRet(url, parms['LOGPath'] + logName)
            # 判断返回值code为200，则检查返回值内容是否正确
            if urlRet['code'] == 200 and 'retMsg' in urlRet['read'] and type(urlRet['read']['retMsg']) == dict:
                data = urlRet['read']['retMsg']
                # 判断返回值是否正确
                if common.check_list(data, n_list, 3) and type(data['listInfo']) == list:
                    checkNum = 0
                    for lInfo in data['listInfo']:
                        if common.check_list(lInfo, info_list, 3) and common.check_list(lInfo, con_list, 2) and lInfo['action'] in config_api.GLOBAL_action:
                            errNum = '0'
                            logMsg += 'blankType:%s, code:%s, name：%s \n' % (blankType, lInfo['productCode'], lInfo['productName'])

                            # 获取节目集详情
                            getSeriesInfoByCode(control_name, lInfo['productCode'], False, lInfo['productName'], url)
                            time.sleep(parms['SleepTime'])
                        elif common.check_list(lInfo, info_list, 3) and common.check_list(lInfo, con_list, 2):
                            errNum = '823'
                            logMsg += 'name：%s, action: %s。\n' % (lInfo['productName'], lInfo['action'])
                        elif common.check_list(lInfo, info_list, 3):
                            errNum = '824'
                            logMsg += 'code:%s, name：%s \n' % (lInfo['productCode'], lInfo['productName'])
                        elif common.check_list(lInfo, info_list, 2):
                            errNum = '825'
                            logMsg += 'code:%s, name：%s \n' % (lInfo['productCode'], lInfo['productName'])
                        else:
                            errNum = '826'
                        # 检查空白推荐下的条目数
                        checkNum += 1
                        if checkNum >= config_api.GLOBAL_checkSearchTopNum:
                            break
                elif common.check_list(data, n_list, 3):
                    errNum = '822'
                elif common.check_list(data, n_list, 2):
                    errNum = '820'
                else:
                    errNum = '821'
            else:
                # 连接出现问题，获取错误码信息
                errNum = urlRet['code']

                if 'read' in urlRet:
                    logMsg += str(urlRet['read'])
            # 写日志和发邮件的内容在这里组合
            if not parms == '-1' and parms['NAME'] and parms['LOGPath']:
                ret = common.log_mail(parms['NAME'], apiCode, errNum, logMsg, url, parms['LOGPath'], logName)
                if ret != 1:
                    errNum = '7'
            time.sleep(parms['SleepTime'])
    else:
        errNum = '-1'

    return errNum

# 获取热门推荐推荐接口
def searchTop(control_name):
    errNum = '9'
    url = ''
    logName = control_name + '_searchTop_log.txt'
    apiCode = '[118]'
    # 判断关键节点是否存在
    # retMsg下必须存在的节点，且不能为空值
    n_list = {'count', 'pageLimit', 'listInfo'}
    # listInfo下必须存在的节点，且不能为空值
    info_list = {'productCode', 'productName', 'itemCode', 'pictureUrl', 'action', 'type'}
    # listInfo下必须存在的节点，允许为空值
    con_list = {'isFee', 'pictureType', 'credits', 'corners'}

    # 判断参数是否正确,如果在列表里，则可以开始拼装参数，发送url请求
    parms = common.getConfig(apiCode, logName, control_name)

    if not parms == '-1':
        errNum = '9'
        # 拼装url
        url = 'http://%s/vod_api/commodityList!searchTop?userCode=%s&serviceGroupCode=%s' % (
            parms['VOD'], parms['UserCode'], parms['ServiceGroupCode'])
        url += common.getRandom()  # 获取随机参数
        logMsg = ''
        # 请求接口
        urlRet = common.getUrlRet(url, parms['LOGPath'] + logName)
        # 判断返回值code为200，则检查返回值内容是否正确
        if urlRet['code'] == 200 and 'retMsg' in urlRet['read'] and type(urlRet['read']['retMsg']) == dict:
            data = urlRet['read']['retMsg']
            # 判断返回值是否正确
            if common.check_list(data, n_list, 3) and type(data['listInfo']) == list:
                checkNum = 0
                for lInfo in data['listInfo']:
                    if common.check_list(lInfo, info_list, 3):
                        logMsg += 'code:%s, name：%s \n' % (lInfo['productCode'], lInfo['productName'])
                        if common.check_list(lInfo, con_list, 2) and lInfo['action'] in config_api.GLOBAL_action:
                            errNum = '0'
                        elif common.check_list(lInfo, con_list, 2):
                            errNum = '833'
                        else:
                            errNum = '834'
                        # 获取节目集详情
                        getSeriesInfoByCode(control_name, lInfo['productCode'], False, lInfo['productName'], url)
                        time.sleep(parms['SleepTime'])
                    elif common.check_list(lInfo, info_list, 2):
                        errNum = '835'
                        logMsg += 'code:%s, name：%s \n' % (lInfo['productCode'], lInfo['productName'])
                    else:
                        errNum = '836'
                        if common.check_list(lInfo, {'productCode', 'productName'}, 3):
                            logMsg += 'code:%s, name：%s \n' % (lInfo['productCode'], lInfo['productName'])
                    # 检查空白推荐下的条目数
                    checkNum += 1
                    if checkNum >= config_api.GLOBAL_checkSearchTopNum:
                        break
            elif common.check_list(data, n_list, 3):
                errNum = '832'
            elif common.check_list(data, n_list, 2):
                errNum = '830'
            else:
                errNum = '831'
        else:
            # 连接出现问题，获取错误码信息
            errNum = urlRet['code']

            if 'read' in urlRet:
                logMsg += str(urlRet['read'])
        # 写日志和发邮件的内容在这里组合
        if not parms == '-1' and parms['NAME'] and parms['LOGPath']:
            ret = common.log_mail(parms['NAME'], apiCode, errNum, logMsg, url, parms['LOGPath'], logName)
            if ret != 1:
                errNum = '7'
    else:
        errNum = '-1'

    return errNum


# if config_api.GLOBAL_debugType == 1:
    # getWallPaper('ITV5')
    # getTagList('ITV5')
    # recommend_box('ITV5')
    # blankBySerach('ITV5')
    # searchTop('ITV5')