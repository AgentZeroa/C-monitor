#!/usr/bin/env python
# -*- coding: utf-8 -*-
# 判断获取EPG5.0壁纸(wallpaper!getData)接口返回的retCode是否正确

import common

def getWallPaper(control_name):
    errNum = '9'
    url = ''
    logName = control_name + '_getWallPaper_log.txt'
    apiCode = '[114]'
    logMsg = ''

    # 判断关键节点是否存在
    n_list = {'count', 'listInfo'}           # retMsg下必须存在的节点，且不能为空值
    c_list = {'code', 'name', 'serviceCombo', 'reduceUrl', 'httpUrl'}    # retMsg['listInfo']下必须存在的节点，且不能为空值

    # 判断参数是否正确,如果在列表里，则可以开始拼装参数，发送url请求
    parms = common.getConfig(apiCode, logName, control_name)

    if not parms == '-1':
        errNum = '9'
        w_type = 0
        while w_type < 2:
            w_type += 1
            # 拼装url
            url = 'http://%s/oms_api/wallpaper!getData?test=1&comboCode=%s&type=%s' % (parms['OMS'], parms['ServiceComboCode'], w_type)
            url += common.getRandom()  # 获取随机参数
            # 请求接口
            urlRet = common.getUrlRet(url, parms['LOGPath'] + logName)

            # 判断返回值code为200，则检查返回值内容是否正确
            if urlRet['code'] == 200 and 'retMsg' in urlRet['read'] and type(urlRet['read']['retMsg']) == dict:
                data = urlRet['read']['retMsg']
                # 判断返回值是否正确
                if common.check_list(data, n_list, 3) and type(data['listInfo']) == list:
                    logMsg = '获取壁纸数量为：%s \n' % data['count']
                    for info in data['listInfo']:
                        if common.check_list(info, c_list, 3):
                            logMsg += 'code: ' + info['code'] + '；name: ' + info['name'] + '\n '
                            errNum = '0'
                        elif common.check_list(info, c_list, 2):
                            errNum = '790'
                            logMsg += 'name：' + info['name'] + '；code：' + info['code'] + '\n'
                            break
                        else:
                            errNum = '791'
                            logMsg += str(info) + '\n'
                            break
                elif common.check_list(data, n_list, 2):
                    errNum = '792'
                else:
                    errNum = '793'
            else:
                # 连接出现问题，获取错误码信息
                errNum = urlRet['code']

                if 'read' in urlRet:
                    logMsg += str(urlRet['read'])

            # 写日志和发邮件的内容在这里组合
            if not parms == '-1' and parms['NAME'] and parms['LOGPath']:
                ret = common.log_mail(parms['NAME'], apiCode, errNum, logMsg, url, parms['LOGPath'], logName)
                if ret != 1:
                    errNum = '7'
    else:
        errNum = '-1'

    return errNum
