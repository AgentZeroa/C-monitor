# -*- coding: utf-8 -*-

from deviceAuth import *
from deviceInit import *
import getRecommendInfo
from getNavigationInfo import *
from getCategoryList import *
from getCommodityListBySerach import *
from getSeriesInfoByCode import *
from getBms import *
from check_apk import *
from getWallPaper import *
from getUMS import *
from getEPG5 import *
from seriesInfo import *
import sys

if len(sys.argv) > 1:
        control_name = sys.argv[1]
else:
        control_name = 'JS4K'

deviceAuth(control_name)
deviceInit(control_name)
if not control_name == 'JS4K':
        getNavigationInfo(control_name)
getCategoryList(control_name)
getCommodityListBySerach(control_name, 'SSS')
bms_main(control_name)
check_APK(control_name)

if control_name == 'ITV5':
        seriesInfo(control_name)

if len(sys.argv) > 2 and sys.argv[2] == '5':
        #getWallPaper(control_name)
        getTagList(control_name)
        recommend_box(control_name)
        blankBySerach(control_name)
        searchTop(control_name)
                                  
