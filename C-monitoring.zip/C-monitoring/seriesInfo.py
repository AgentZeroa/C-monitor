#!/usr/bin/env python
# -*- coding: utf-8 -*-
# '[127]': '防盗链，目前仅限ITV5（seriesInfo!getAuthInfo）'

import common

def seriesInfo(control_name):
    errNum = '9'
    logPath = './'
    logMsg = ''
    logName = control_name+'_seriesInfo_log.txt'
    apiCode = '[127]'       # 防盗链，目前仅限ITV5
    control_list = {'ITV5'}
    url = ''

    # 判断参数是否正确,如果在列表里，则可以开始拼装参数，发送url请求
    parms = common.getConfig(apiCode, logName, control_name)

    if not parms == '-1' and control_name in control_list:
        url = 'http://%s/vod_api/seriesInfo!getAuthInfo?domainCode=%s' % (parms['VOD'], parms['DomainCodes'])
        url += '&clientID=1467688170652983&contentID=2100140023526766744250294&'
        url += 'playUrl=http://vod.cibn.ctlcdn.com/ceph_006/static/video/00000823000022018011221030205451/playlist.m3u8'
        url += '&extraInformation=ac:4a:fe:a0:f8:cf_100.200.201'
        url += common.getRandom()  # 获取随机参数

        # 请求接口
        urlRet = common.getUrlRet(url, parms['LOGPath'] + logName)

        # 判断返回值code为200，则检查返回值内容是否正确
        if urlRet['code'] == 200 and 'retMsg' in urlRet['read']:
            data = urlRet['read']['retMsg']
            # 判断返回值是否正确
            if len(data) > 100:
                errNum = '0'
            else:
                errNum = '840'
        else:
            # 连接出现问题，获取错误码信息
            errNum = urlRet['code']

        if not errNum == '0' and 'read' in urlRet:
            logMsg += str(urlRet['read']) + '\n'
    else:
        errNum = '841'

    #写日志和发邮件的内容在这里组合
    if not parms == '-1' and parms['NAME'] and parms['LOGPath']:
        ret = common.log_mail(parms['NAME'], apiCode, errNum, logMsg, url, parms['LOGPath'], logName)
        if ret != 1:
            errNum = '7'

    return errNum


#if config_api.GLOBAL_debugType == 1:
#   seriesInfo('TEST')