#!/usr/bin/env python
# -*- coding: utf-8 -*-

import common

def deviceInit(control_name, mac = ''):
    errNum = '9'
    logName = control_name + '_Init_log.txt'
    apiCode = '[102]'
    logMsg = ''
    num = 0

    # 判断参数是否正确,如果在列表里，则可以开始拼装参数，发送url请求
    parms = common.getConfig(apiCode, logName, control_name)

    if not parms == '-1':
        # 拼装url
        if mac == '':
            mac = parms['MAC']
        url = 'http://%s/oms_api/device!deviceInit?mac=%s' % (parms['OMS'], mac)
        if parms['InitType'] == 'front':
            url += '&externalUserCode=%s&comboCode=%s' % (parms['ExternalUserCode'], parms['ServiceComboCode'])
        url += common.getRandom()  # 获取随机参数

        # 请求接口
        urlRet = common.getUrlRet(url,parms['LOGPath'] + logName)

        # 判断返回值code为200，则检查返回值内容是否正确
        if urlRet['code'] == 200 and 'retMsg' in urlRet['read']:
            data = urlRet['read']['retMsg']
            # 判断返回值是否正确
            c_list = {'serviceComboCode': parms['ServiceComboCode'], 'agentCode': parms['AgentCode']}
            if type(data) == dict and common.check_list(data, c_list) and type(data['serviceGroupList']) == list:
                for i in data['serviceGroupList']:
                    s_list = {'serviceGroupCode': parms['ServiceGroupCode'], 'serviceComboCode': parms['ServiceComboCode']}
                    if type(i) == dict and common.check_list(i, s_list):
                        errNum = '0'
                    else:
                        errNum = '762'
                        logMsg += '预期返回：serviceGroupCode: '+parms['ServiceGroupCode']+', serviceComboCode: '+parms['ServiceComboCode']+'\n'
                        logMsg += '实际返回：' + str(i) + '\n'
                        break
                    logMsg += 'serviceGroupList下的serviceGroupCode=' + i['serviceGroupCode'] + '；\n serviceComboCode=' + i['serviceComboCode'] +'； \n'
            else:
                errNum = '761'
                logMsg += '预期返回：serviceComboCode: ' + parms['ServiceComboCode'] + ', agentCode: ' + parms['AgentCode'] + '\n'
                logMsg += '实际返回：' + str(data) + '\n'
        else:
            # 连接出现问题，获取错误码信息
            errNum = urlRet['code']
            logMsg += str(urlRet['read']) + '\n'

    # 写日志和发邮件的内容在这里组合
    if not parms == '-1' and parms['NAME'] and parms['LOGPath']:
        ret = common.log_mail(parms['NAME'], apiCode, errNum, logMsg, url, parms['LOGPath'], logName)
        if ret != 1:
            errNum = '7'
    return errNum

# if config_api.GLOBAL_debugType == 1:
#     deviceInit('JSYD')