# !/usr/bin/env python
# -*- coding: utf-8 -*-


# 日志统计功能的平台编号
GLOBAL_logCode = {
    '江苏移动': '[C001]', '江苏移动4K': '[C002]', '大数据测试': '[C003]', '电信悦me-EPG5': '[C004]',
    '山东移动': '[C010]', '山东中兴增值': '[C011]', '山东华为增值': '[C012]',
    '甘肃电信': '[C020]',
    '陕西有线': '[C030]',
    '四川移动': '[C040]',
    '深圳天威': '[C050]', '深圳天威-EPG5': '[C51]',
    '安徽移动': '[C060]', '安徽移动-EPG5': '[C061]',
    '福建联通': '[C070]',
    '测试环境': '[T001]'
}
# 清缓存后缀
GLOBAL_delete_redis = '&delete_redis=1'

# python代码和log的根路径
GLOBAL_rootLogPath = '/opt/Interface_test_scripts/'
# 发送邮件日志
GLOBAL_mailLog = GLOBAL_rootLogPath + 'mail_log/mail_log.txt'
# 缺集日志名
GLOBAL_missSetLog = 'miss_set.log'
# 剧集编号为0，日志名
GLOBAL_errSequenceLog = 'Sequence_err.log'

# 遍历栏目树时发送一条请求后sleep的时间（秒），以免对服务器造成压力
GLOBAL_sleepTime = 5
# 盒端请求列表页的pageLimit数量
GLOBAL_pageLimit = 200

# 检查列表页、关联推荐、空白推荐下的条目数，设置为大于0的数字，不建议设的太大，关联推荐最多显示20条
GLOBAL_checkListNum = 1

# 热门搜索下的检查条目数
GLOBAL_checkSearchTopNum = 25

# 专题包中最少的产品数
GLOBAL_ZTNum = 6

# Modifier：linjingjing by 20171212 EPG5.0推荐位判断第二行的宽高参数是否正确
GLOBAL_width_2 = 250
GLOBAL_height_2 = 375
# Modifier：linjingjing by 20180104 EPG5.0筛选标签列表
GLOBAL_tagList = {'MOVIECATE', 'ORIGINALCOUNTRY', 'RELEASEYEAR'}
# Modifier：linjingjing by 20180108 EPG5.0搜索推荐列表
GLOBAL_boxList = {1, 2, 3, 4}
# Modifier：linjingjing by 20180108 EPG5.0空白推荐列表
GLOBAL_blankList = {0, 1}
# 返回值判断
GLOBAL_retCode = '00000000'
GLOBAL_retName = 'retCode'
GLOBAL_action = {'OPEN_SEARCH', 'OPEN_HISTORY', 'OPEN_FAVOR', 'OPEN_DETAIL', 'OPEN_SETTINGS', 'OPEN_ABOUT_US',
                 'OPEN_PROGRAM_LIST', 'OPEN_SPECIAL_INDEX', 'OPEN_SPECIAL_TEMPLATE_1', 'OPEN_H5',
                 'OPEN_PLAYER', 'OPEN_APP', 'OPEN_PROGRAM', 'OPEN_LIVEPLAYER'}

# 连接接口超时时间设置
GLOBAL_setTimeOut = 30

# 监控邮件相关，发件人，邮箱密码，收件人，发送邮件的日志名
GLOBAL_sender = 'zentao@guttv.cn'
GLOBAL_password = 'Hqhychandao123'
GLOBAL_receivers = ['linjingjing@guttv.cn', 'luoyang@guttv.cn', 'test@guttv.cn']
# 邮件发送的标题
GLOBAL_mailSubject = '接口访问异常邮件'

# 微信公众号的设置
GLOBAL_CorpID = 'wxbbdcd40df552a661'
GLOBAL_Secret = '3W8UxdHVvUsfw-_ZaULTj9HlK5wBKub4-0_61YBYQrc6laIuQ0IUxN_OARkpDdlk'
# agentid 在微信公众号——应用中心——点击自建应用，可看到应用ID为1
GLOBAL_agentid = 1
GLOBAL_weixin_url = 'https://qyapi.weixin.qq.com'
GLOBAL_weixin_log = GLOBAL_rootLogPath + 'mail_log/weixin.log'

# 钉钉消息设置
GLOBAL_DingDing_token = '57f61392c16751b3b25427c4eff0c58f60c4ec2c67e359aeb50dfd65f8545d05'

# 随机参数的名字
GLOBAL_Random_name = 'check_test'

# 该值设置为1开启调试模式，日志存在本地，邮件只发给调试人员，放在服务器上改为除1、2、3、4以外的任意数
# 设置为2，则是青云服务器上log路径
# 设置为3，则是105上每周轮循一次所有产品的设置
GLOBAL_debugType = 1
if GLOBAL_debugType == 1:
    GLOBAL_rootLogPath = 'D:/py/log/'
    GLOBAL_mailLog = 'D:/py/log/mail_log.txt'
    GLOBAL_sleepTime = 1
    GLOBAL_receivers = ['linjingjing@guttv.cn']
    GLOBAL_weixin_log = 'D:/py/log/weixin.log'
    GLOBAL_checkListNum = 1  # 每个一级分类下检查节目集详情的数量
elif GLOBAL_debugType == 2:     # 青云服务器上的log路径和其他需要修改的参数
    # log的路径
    GLOBAL_rootLogPath = '/opt/Interface_test_scripts/'
    # 发送邮件日志
    GLOBAL_mailLog = GLOBAL_rootLogPath + 'mail_log/mail_log.txt'
    GLOBAL_weixin_log = GLOBAL_rootLogPath + 'mail_log/weixin.log'
    GLOBAL_Random_name = 'check_yunwei'
    # 报警邮件发送给以下邮箱
    GLOBAL_receivers = ['yunwei@guttv.cn', 'zhangzhijian@guttv.cn']
    # 设置微信公众号的设置
    GLOBAL_CorpID = 'wxbe729a7a0663459c'
    GLOBAL_Secret = 'DRruiSSWhq75K2Getlj6IQ45zD9NIbb02VJU-vhvvg0KS8ejTK731DjLYm0jRqPv'
    # 设置钉钉token， 长度小于10位，表示不发送钉钉
    GLOBAL_DingDing_token = '3eaba69ef8c7ac562ae9e93669a16b8ad9ed587ec53bb7b136dc87664e5a6227'
elif GLOBAL_debugType == 3:  # 105上的配置，轮循所有的产品
    GLOBAL_checkListNum = 10000     # 每个一级分类下检查节目集详情的数量
    # python代码和log的根路径
    GLOBAL_rootLogPath = '/opt/guttv/python3/'
    # 发送邮件和微信的日志
    GLOBAL_mailLog = GLOBAL_rootLogPath + 'mail_log/mail_log.txt'
    GLOBAL_weixin_log = GLOBAL_rootLogPath + 'mail_log/weixin.log'
    # 遍历栏目树时发送一条请求后sleep的时间（秒），以免对服务器造成压力
    GLOBAL_sleepTime = 1
elif GLOBAL_debugType == 4:
    GLOBAL_rootLogPath = 'D:/py/log/'
    GLOBAL_mailLog = 'D:/py/log/mail_log.txt'
    GLOBAL_sleepTime = 1
    GLOBAL_receivers = ['linjingjing@guttv.cn']
    GLOBAL_weixin_log = 'D:/py/log/weixin.log'
    GLOBAL_checkListNum = 50  # 每个一级分类下检查节目集详情的数量

